
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Na Li@nali@bgc-jena.mpg.de

This file is to plot Figures in PhD thesis chapter 4.
   
"""


import scipy
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import seaborn as sns
from cmip_treatment import order_file, cmip_emeg_pixel

def future_plot(f_future, f_out, name, time):
    date = np.arange(2016, 2101)
    model = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5', 'IPSL-CM6A-LR', 
             'MPI-ESM1-2-LR']
    # model = ['CESM2-LE']
    star, mid, end = 2016, 2050, 2100
    fig, ax = plt.subplots(1, 5, figsize=(28, 3.7), dpi=300)
    m = 0
    for k in model:
         
        if k == 'CESM2-LE':
            scen = ['ssp370']
            scen2 = ['SSP3-7.0']
            colo = ['#338F99']
        else:
            scen = ['ssp126', 'ssp245', 'ssp370', 'ssp585']
            scen2 = ['SSP1-2.6', 'SSP2-4.5', 'SSP3-7.0', 'SSP5-8.5']
            colo = ['#D43F21', '#D3B016', '#338F99', '#BE69CF']
        print(k)
        n = 0
        for h in scen:
            df = cmip_emeg_pixel(f_future, f_out, h, star, mid, end, k, name)
            print(df.shape)
            if df.shape[-1] == 1:
                df = df.reshape(df.shape[0], df.shape[1])
            for i in range(len(df)):
                ax[m].plot(date, df[i], alpha=0.4, 
                            color = colo[n], lw=0.2)
            ax[m].plot(date, np.nanmean(df, axis=0), color= colo[n], 
                        lw = 2.5, label='{} ({})'.format(scen2[n], len(df)))
        
           
            if name == 'nbp':
                ax[m].set_ylabel('NBP ' + r'($gC \cdot m^{-2} \cdot yr^{-1}$)')
                ax[m].set_ylim(-30, 115)
                ax[m].axhline(y=0, color='k',lw=.5, alpha=0.5, linestyle='--')
               
                if k == 'CanESM5':
                    ax[m].text(2050, 90, k)
                else:
                    ax[m].text(2025, 90, k)
            if name == 'gpp':
                ax[m].set_ylabel('GPP ' + r'($gC \cdot m^{-2} \cdot yr^{-1}$)')
                ax[m].set_ylim(400, 1800)
                ax[m].axhline(y=120, color='k',lw=.5, alpha=0.5, linestyle='--')
                ax[m].text(2025, 1600, k)
            if name == 'res':
                ax[m].set_ylabel('TER ' + r'($gC \cdot m^{-2} \cdot yr^{-1}$)')
                ax[m].set_ylim(400, 1800)
                ax[m].axhline(y=120, color='k',lw=.5, alpha=0.5, linestyle='--')
                ax[m].text(2025, 1600, k)
            n += 1
        # if k == 'ACCESS-ESM1-5':
        ax[m].legend(frameon=False,  fontsize=9)   
            
        if k == 'IPSL-CM6A-LR' or k == 'MPI-ESM1-2-LR':
            if name == 'nbp':
                loc = 'lower left'
        else:
            loc = 'upper left'
        
        ax[m].set_xlabel('Years')
        m += 1
    
    # plt.tight_layout()
    plt.savefig(f_out + '{}_annu_sum_global_future.pdf'.format(name), dpi=300)
    plt.close()
    
def heat_map(f_in, f_out, name):
    si = ['emergence', 'noise', 'signal']
    si_ = ['(A) ToE', '(B) N', '(C) S']
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    lab =  ['ToE (Years)', 'N', 'S']
    scen2 = ['SSP1-2.6', 'SSP2-4.5', 'SSP3-7.0', 'SSP5-8.5']
    fig, ax = plt.subplots(1, 3, figsize=(15, 3.5), dpi=300, sharey=True)
    n = 0
    for i in si:
        df = {}
        for h in [h for h in os.listdir(f_in) if h.endswith('{}_global.csv'.format(i))]:
            print(h)
            
            file = pd.read_csv(os.path.join(f_in, h), index_col=0)
            
            # file.index.name = 'model'
            print(file)
            df = np.around(file, decimals=1, out=None).T
            df[df == 0] = np.nan
            cmap = sns.color_palette('rocket_r', 10)
            
            if i == 'emergence':
                vmin_ = 0
                vmax_ = 100
            if i == 'noise':
                vmin_ = 10
                vmax_ = 60
            if i == 'signal':
                vmin_ = 0.25
                vmax_ = 2.75
            print(vmin_)
            
            sns.heatmap(df, cmap=cmap, vmin=vmin_, vmax=vmax_, cbar=True, cbar_kws={'label': lab[n]},
                        annot=True, annot_kws={'size': 12}, fmt='g', ax=ax[n], 
                        xticklabels=scen2) 
            ax[n].set_title('{}'.format(si_[n]))
        n += 1
    # plt.tight_layout()
    plt.savefig(f_out + 'heatmap_{}_future_global.pdf'.format(name), dpi=300)
    plt.close()


def global_plot(f_nbp_cmip6, f_out, name):
    date = np.arange(1851, 2015)
    model = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5', 'IPSL-CM6A-LR', 
             'MPI-ESM1-2-LR']
    fig, ax = plt.subplots(5, 1, figsize=(7.4, 8), dpi=300)
    n = 0
    for k in model:
        print(k)
        f_list = order_file(f_nbp_cmip6, k, 'global', name)
        df_all = np.zeros((len(f_list), 164))
        print(df_all.shape)
        m = 0
        for i in [i for i in f_list if i.endswith('nc')]:
            df = xr.open_dataset(i)
            df = df.sel(time=slice('1851-01-31', '2014-12-31'))
            if k == "CESM2-LE":
                if name=='gpp':
                    df = df.GPP
                if name=='nbp':
                    df = df.NBP 
                df_all[m] = np.asarray(df.values).ravel()
            else:
                if name=='gpp':
                    df = df.gpp
                if name=='nbp':
                    df = df.nbp
                
                df_all[m] = np.asarray(df.values).ravel()
            m += 1
        mean_all = np.asarray(df_all)
        for i in range(len(mean_all)):
            ax[n].plot(date, mean_all[i], alpha=0.3, 
                        color = '#757678', lw=0.1)
        ax[n].plot(date, np.nanmean(mean_all, axis=0), color= '#2C3936', 
                    lw = 1.5, label='{} ({})'.format(k, len(df_all)))
    
        ax[n].set_ylabel(r'$gC \cdot m^{-2} \cdot yr^{-1}$')
        if name == 'nbp':
            ax[n].set_ylim(-35, 40)
            ax[n].axhline(y=0, color='k',lw=.5, alpha=0.5, linestyle='--')
        if name == 'gpp':
            ax[n].set_ylim(300, 1100)
            ax[n].axhline(y=120, color='k',lw=.5, alpha=0.5, linestyle='--')
        ax[n].legend(frameon=False,  loc='upper left')
        n += 1
    for a in ax.flat:
        a.label_outer()
    plt.xlabel('Year')
    plt.savefig(f_out + '{}_annu_sum_global_1851_2014.pdf'.format(name), dpi=300)
    plt.close()
    
def res_global_plot(f_res, f_gpp, f_out):
    date = np.arange(1851, 2015)
    model = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5', 'IPSL-CM6A-LR', 
             'MPI-ESM1-2-LR']
    fig, ax = plt.subplots(5, 1, figsize=(7.4, 8), dpi=300)
    n = 0
    for k in model:
        print(k)
        f_list_res = order_file(f_res, k, 'global', 'res')
        f_list_gpp = order_file(f_gpp, k, 'global', 'gpp')
        
        df_all = np.zeros((len(f_list_res), 164))
        df_all2 = np.zeros((len(f_list_gpp), 164))
        print(df_all.shape)
        print(df_all2.shape)
       
        s = 0
        for j in [j for j in f_list_gpp if j.endswith('nc')]:
            df2 = xr.open_dataset(j)
            df2 = df2.sel(time=slice('1851-01-31', '2014-12-31'))
            
            if k == "CESM2-LE":
                df2 = df2.GPP
            else:
                df2 = df2.gpp
            df_all2[s] = np.asarray(df2.values).ravel()
            s += 1
        mean_all2 = np.asarray(df_all2)
        for i in range(len(mean_all2)):
            ax[n].plot(date, mean_all2[i], alpha=0.3, color = '#757678', lw=0.1)
        ax[n].plot(date, np.nanmean(mean_all2, axis=0), color= '#2C3936', 
                    lw = 1.5, label='GPP ({})'.format(len(df_all2)))
        
        m = 0
        for i in [i for i in f_list_res if i.endswith('nc')]:
            df = xr.open_dataset(i)
            df = df.sel(time=slice('1851-01-31', '2014-12-31'))
            
            if k == "CESM2-LE":
                df = df.RES
            else:
                df = df.res
            df_all[m] = np.asarray(df.values).ravel()
            m += 1
        mean_all = np.asarray(df_all)
        for i in range(len(mean_all)):
            ax[n].plot(date, mean_all[i], alpha=0.3, color = 'red', lw=0.1)
        ax[n].plot(date, np.nanmean(mean_all, axis=0), color= 'red', 
                    lw = 1.5, label='TER ({})'.format(len(df_all)))
        ax[n].text(1920, 950, k)
        ax[n].set_ylabel(r'$gC \cdot m^{-2} \cdot yr^{-1}$')
        ax[n].set_ylim(300, 1100)
        ax[n].axhline(y=120, color='k',lw=.5, alpha=0.5, linestyle='--')
        if k == 'IPSL-CM6A-LR' or k == 'MPI-ESM1-2-LR':
            ax[n].legend(frameon=False,  loc='lower left')
        else:
            ax[n].legend(frameon=False,  loc='upper left')
        n += 1
    for a in ax.flat:
        a.label_outer()
    plt.xlabel('Year')
    plt.savefig(f_out + 'res_gpp_annu_sum_global_1851_2014.pdf', dpi=300)
    plt.close()
    

def time_ermer_plot(f_perc, f_out, name):
    tit = ['5_5', '10_10', '20_20', '30_30',
             '45_45', '60_60'] 
    model_list = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  
                  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    d = {'Resolution':[], 'Model':[], 'ToE':[]}
    
    for h in model_list:
        for i in [i for i in sorted(os.listdir(f_perc)) if i == h]:
            print(i)
            for k in tit:
                for j in [j for j in sorted(os.listdir(os.path.join(f_perc, i))) if 
                          j.split('_')[-1] == 'emergence.npy' and 
                          j.split('_')[-4] + '_' + j.split('_')[-3] == k]:
                    print(j)
                    df = os.path.join(f_perc + h, j)
                    df = np.load(df)
                    df = df[~np.isnan(df)]
                    df = df.tolist()
                    if h == 'ACCESS-ESM1-5':
                        print(np.min(df), np.max(df))
                    d['Model'].extend(np.repeat(h, len(df)).tolist())
                    d['Resolution'].extend(np.repeat(k, len(df)).tolist())
                    d['ToE'].extend(df)
                    
        print(f_perc)
        for p in [p for p in os.listdir(f_perc) if p.endswith('global.csv') 
                  and p.split('_')[-2] == 'emergence']:
            print(p)
            df = os.path.join(f_perc, p)
            df = pd.read_csv(df, index_col=0)
            print(df)
            # df = df[~np.isnan(np.asarray(df))]
            df = np.asarray(df[h]).tolist()
            
            d['Model'].extend(np.repeat(h, len(df)).tolist())
            d['Resolution'].extend(np.repeat('global', len(df)).tolist())
            d['ToE'].extend(df)
               
    d = pd.DataFrame(d)
    print(d)
    print(d[d['Resolution']=='global'])
   
    colo = ['#D43F21', '#28851E', '#D3B016', '#338F99', '#BE69CF']
    sns.catplot(
    data=d, x="Resolution", y="ToE", hue="Model",palette=colo, legend_out=False, 
    kind="box", height=4, aspect=2, boxprops=dict(alpha=.7), whis=2, 
    linewidth=0.5, fliersize=1, saturation=0.7)
    plt.hlines(200, xmin=-0.5, xmax=6, linestyle='--', alpha=0.9, lw=0.4, color='#3D3D3D')
    if name == 'nbp':
        plt.ylim(0, 800)
    if name == 'gpp' or name== 'res':
        plt.ylim(0, 800)
    plt.legend(frameon=False)
    
    plt.savefig(f_out + '{}_time_emer_all.pdf'.format(name), dpi=300)
    # d.to_csv(f_perc + 'cmip6_seaborn_box_{}.csv'.format(name))

        
def plot_bar(f_in_ori, f_in_RR, f_fut, f_fut_RR, f_out, name, seas):
    print(name)
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    colo = ['#2C3936', '#D43F21', '#D3B016', '#338F99', '#BE69CF']
    scen2 = ['Historical', 'SSP1-2.6', 'SSP2-4.5', 'SSP3-7.0', 'SSP5-8.5']
    ori = pd.read_csv(f_in_ori, index_col=0)
    RR = pd.read_csv(f_in_RR, index_col=0)
    ori_fut = pd.read_csv(f_fut, index_col=0)
    RR_fut = pd.read_csv(f_fut_RR, index_col=0)
    ori = pd.concat((ori, ori_fut))
    RR = pd.concat((RR, RR_fut))
    RR.index = ori.index
    relevant = 100 * (ori-RR)/ori
    print(relevant)
    
    fig, ax = plt.subplots(1, 5, figsize=(28, 3.7), dpi=300)
    n = 0
    for k in code:
        origin = np.asarray(ori[k])
        origin[origin == 0] = np.nan
        origin = np.around(origin, decimals=1, out=None)
        rr = np.asarray(RR[k])
        rr[rr == 0] = np.nan
        rr = np.around(rr, decimals=1, out=None)

        x = np.arange(len(code))
        width = 0.35
        
        rects1 = ax[n].bar(x - width/2, origin, width, label='Original', color=colo, alpha=0.3)
        rects2 = ax[n].bar(x + width/2, rr, width, label='Residual', color=colo, edgecolor='black', linewidth=0.5)

        # Add some text for labels, title and custom x-axis tick labels, etc.
        ax[n].set_ylabel('ToE (Years)')
        # ax.set_title('{} ime of emergence ')
        ax[n].set_xticks(x)
        ax[n].set_xticklabels(scen2)
        if name == 'nbp':
            ax[n].set_ylim(10, 500)
            ax[n].text(1.5, 450, k)
        if name == 'gpp':
            ax[n].set_ylim(0, 130)
            ax[n].text(1.5, 110, k)
         
        if n == 1:
            ax[n].legend()
        ax[n].set_xlabel('Scenario')
        def autolabel(rects):
            """Attach a text label above each bar in *rects*, displaying its height."""
            for rect in rects:
                height = rect.get_height()
                ax[n].annotate('{}'.format(height),
                            xy=(rect.get_x() + rect.get_width() / 2, height),
                            xytext=(0, 3),  # 3 points vertical offset
                            textcoords="offset points",
                            ha='center', va='bottom', fontsize=8.5)

        autolabel(rects1)
        autolabel(rects2)
        n += 1
    fig.tight_layout()
    plt.savefig(f_out + 'Time_of_emergence_ori_rr_{}_{}.pdf'.format(name, seas))
    plt.close()

def relevant_change(f_in_ori, f_in_RR, f_fut, f_fut_RR, f_out, name, seas):
    print(name)
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    colo = ['#2C3936', '#D43F21', '#D3B016', '#338F99', '#BE69CF']
    scen2 = ['Historical', 'SSP1-2.6', 'SSP2-4.5', 'SSP3-7.0', 'SSP5-8.5']
    ori = pd.read_csv(f_in_ori, index_col=0)
    RR = pd.read_csv(f_in_RR, index_col=0)
    ori_fut = pd.read_csv(f_fut, index_col=0)
    RR_fut = pd.read_csv(f_fut_RR, index_col=0)
    ori = pd.concat((ori, ori_fut))
    
    RR = pd.concat((RR, RR_fut))
    RR.index = ori.index
    relevant = 100 * (ori-RR)/ori
    print(relevant)

if __name__ == '__main__':
    
    f_nbp = '.../data/nbp/'
    f_gpp = '.../data/gpp/'
    f_res = '.../data/res/'
   
    f_nbp_emer = '.../results/emerge/nbp_emer/'
    f_gpp_emer = '.../results/emerge/gpp_emer/'
    f_res_emer = '.../results/emerge/res_emer/'
    
    f_nbp_RR = '.../results/RR/history/nbp/'
    f_gpp_RR = '.../results/RR/history/gpp/'

    f_nbp_emer_RR = '.../results/emerge/nbp_emer_RR/'
    f_gpp_emer_RR = '.../results/emerge/gpp_emer_RR/'
    
    f_nbp_future = '.../data/nbp_future/'
    f_gpp_future = '.../data/gpp_future/'
    f_res_future = '.../data/res_future/'
    
    f_nbp_future_emer = '.../results/emerge/nbp_future_emer/'
    f_gpp_future_emer = '.../results/emerge/gpp_future_emer/'
    f_res_future_emer = '.../results/emerge/res_future_emer/'
    
    f_nbp_future_RR = '.../results/RR/future/nbp/'
    f_gpp_future_RR = '.../results/RR/future/gpp/'
    
    f_nbp_future_emer_RR = '.../results/emerge/nbp_future_emer_RR/'
    f_gpp_future_emer_RR = '.../results/emerge/gpp_future_emer_RR/'

    
    season = 'djf'
    f_out2 = '.../results/emerge/'
    f_nbp_emer_hist = '.../results/emerge/nbp_emer/nbp_history_emergence_global.csv'
    f_nbp_emer_hist_RR = '.../results/emerge/nbp_emer_RR/RR_nbp_history_emergence_{}_resi.csv'.format(season)
    
    f_gpp_emer_hist = '.../results/emerge/gpp_emer/gpp_history_emergence_global.csv'
    f_gpp_emer_hist_RR = '.../results/emerge/gpp_emer_RR/RR_gpp_history_emergence_{}_resi.csv'.format(season)
    
    f_nbp_emer_fut = '.../results/emerge/nbp_future_emer/nbp_future_emergence_global.csv'
    f_nbp_emer_fut_RR = '.../results/emerge/nbp_future_emer_RR/RR_nbp_future_emergence_{}_global.csv'.format(season)
    
    f_gpp_emer_fut = '.../results/emerge/gpp_future_emer/gpp_future_emergence_global.csv'
    f_gpp_emer_fut_RR = '.../results/emerge/gpp_future_emer_RR/RR_gpp_future_emergence_{}_global.csv'.format(season)
    
    f_nbp_noise_hist = '.../results/emerge/nbp_emer/nbp_history_noise_global.csv'
    f_nbp_noise_hist_RR = '.../results/emerge/nbp_emer_RR/RR_nbp_history_noise_{}_resi.csv'.format(season)
    
    f_gpp_noise_hist = '.../results/emerge/gpp_emer/gpp_history_noise_global.csv'
    f_gpp_noise_hist_RR = '.../results/emerge/gpp_emer_RR/RR_gpp_history_noise_{}_resi.csv'.format(season)
    
    f_nbp_noise_fut = '.../results/emerge/nbp_future_emer/nbp_future_noise_global.csv'
    f_nbp_noise_fut_RR = '.../results/emerge/nbp_future_emer_RR/RR_nbp_future_noise_{}_global.csv'.format(season)
    
    f_gpp_noise_fut = '.../results/emerge/gpp_future_emer/gpp_future_noise_global.csv'
    f_gpp_noise_fut_RR = '.../results/emerge/gpp_future_emer_RR/RR_gpp_future_noise_{}_global.csv'.format(season)
    
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    
# Plot Figure C5, C6, C7
    # time_ermer_plot(f_nbp_emer, f_nbp_emer, 'nbp')
    # time_ermer_plot(f_gpp_emer, f_gpp_emer, 'gpp')
    # time_ermer_plot(f_res_emer, f_res_emer, 'res')
    
# Plot Figure 4.1, C1
    # global_plot(f_nbp, f_nbp_emer, 'nbp')
    # res_global_plot(f_res, f_gpp, f_res_emer)
  
# Plot Figure 4.3, C8, C9
    # future_plot(f_nbp_future, f_nbp_future_emer, 'nbp', 'future')
    # future_plot(f_gpp_future, f_gpp_future_emer, 'gpp', 'future')
    # future_plot(f_res_future, f_res_future_emer, 'res', 'future')
    
# Plot Figure C10, C11, C12
    # heat_map(f_nbp_future_emer, f_nbp_future_emer, 'nbp')
    # heat_map(f_gpp_future_emer, f_gpp_future_emer, 'gpp')
    # heat_map(f_res_future_emer, f_res_future_emer, 'res')

# Plot Figure 4.4, C13    
    # plot_bar(f_nbp_emer_hist, f_nbp_emer_hist_RR, f_nbp_emer_fut, f_nbp_emer_fut_RR, f_out2, 'nbp', season)
    # plot_bar(f_gpp_emer_hist, f_gpp_emer_hist_RR, f_gpp_emer_fut, f_gpp_emer_fut_RR, f_out2, 'gpp', season)
    
# For table C1-C4
    # relevant_change(f_nbp_emer_hist, f_nbp_emer_hist_RR, f_nbp_emer_fut, f_nbp_emer_fut_RR, f_out2, 'nbp', season)
    # relevant_change(f_nbp_noise_hist, f_nbp_noise_hist_RR, f_nbp_noise_fut, f_nbp_noise_fut_RR, f_out2, 'nbp', season)
    # relevant_change(f_gpp_emer_hist, f_gpp_emer_hist_RR, f_gpp_emer_fut, f_gpp_emer_fut_RR, f_out2, 'gpp', season)
    # relevant_change(f_gpp_noise_hist, f_gpp_noise_hist_RR, f_gpp_noise_fut, f_gpp_noise_fut_RR, f_out2, 'gpp', season)
