
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Na Li@nali@bgc-jena.mpg.de

This is to calculate the time of emergence of global and pixel-based scales, for historical run.
   
"""


import scipy
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import matplotlib as mpl
import scipy.stats
from numpy import inf
import cartopy.crs as ccrs
from cartopy.util import add_cyclic_point

# in history, S signal is from 1960-2006

def order_file(f_in, model, res, name):
    if res == 'global_fut' or res == '10_10_fut':
        f_in2 = f_in
    else:
        f_in2 = os.path.join(f_in, res)
    f_new = []
    f_new2 = []
    
    for i in [i for i in sorted(os.listdir(f_in2)) if i.endswith('.nc') 
            and i.split('_')[2]==model]:
        
        if model == 'CESM2-LE':
            if i.split('_')[-5]=='CESM2-LE' and i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:6]=='10':
                    print(i)    
            elif i.split('_')[-5]=='CESM2-LE' and i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:6]=='11':
                    print(i)
            else:
                f_new.append(os.path.join(f_in2, i))   
    
        else:
            f_new.append(os.path.join(f_in2, i))   
    # print(len(f_new))
    if model == "CESM2-LE":
        f_new2 = sorted(f_new)
    else:    
        for j in range(1, len(f_new)+1):
            for i in f_new:
                if len(i.split('_')[-2])>3 and int(i.split('_')[-2][1:-6])==j: 
                    f_new2.append(i) 
            
                if len(i.split('_')[-2])<3 and int(i.split('_')[-3][1:-6])==j: 
                    f_new2.append(i) 
                
    if model == "ACCESS-ESM1-5":
        f_new2.remove(f_new2[24])
        f_new2.remove(f_new2[20])      
    # df = pd.DataFrame(f_new2)
    # df.to_csv(f_in + 'code_list_{}.csv'.format(model), index=False)
    # df.to_csv(f_in + 'test2.csv', index=False)
    return f_new2

def cmip_emeg_pixel(f_in, f_out, resol, star, mid, end, model, name):
    
    f_list = order_file(f_in, model, resol, name)
    print(resol)
    if resol == '2_2':
        lat = int(180//2.5)
        lon = int(360//2.5)
        print(lat, lon)
    elif resol == 'global' or resol[:3] == 'ssp':
        lat = int(180//180)
        lon = int(360//360) 
        print(lat, lon)
        
    else:
        lat = int(180//int(resol.split('_')[1]))
        lon = int(360//int(resol.split('_')[0]))
        print(lat, lon)
    df_all = np.zeros((len(f_list), end-star+1, lat, lon))
    print(df_all.shape)
    n = 0
    for i in [i for i in f_list if i.endswith('nc')]:
        df = xr.open_dataset(i)
        if model != "CESM2-LE":
            if name=='gpp':
                df = df.gpp
            if name=='nbp':
                df = df.nbp
            if name=='res':
                df = df.res
        else:
            if name=='gpp':
                df = df.GPP
            if name=='nbp':
                df = df.NBP 
            if name=='res':
                df = df.RES 
       
        if np.isnan(df.values).all():
            df_all = np.delete(df_all, -1, 0)
            print(df_all.shape)
            n += 0
        else:
            df2 = df.sel(time=slice('{}-01-01'.format(star), 
                                    '{}-12-31'.format(end)))
            df_all[n] = df2.values 
            n += 1
    print(df_all.shape)
    # if model == 'ACCESS-ESM1-5' and resol == 'global':
    #     print(df_all)
    return df_all
        
def linear_regre(tsa, nbp):  
    X = np.asarray(tsa).reshape(-1, 1)
    y = np.asarray(nbp).reshape(-1, 1)
    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(X.ravel(), y.ravel())
    return slope, r_value, p_value

def s_n_cal(df, star, mid):
    
    print('this df shape {}'.format(df.shape))
    print(star, mid)
    
    S = np.mean(df, axis=0)[mid-star+1:]
    S_new = np.zeros((df.shape[2], df.shape[3]))
   
    for i in range(df.shape[2]):
        for j in range(df.shape[3]):
            if np.all(S[:, i, j]==0):
                S_new[i, j] = np.nan 
            else:
                SS, r, p = linear_regre(np.arange(len(S[:, i, j])), S[:, i, j])
                if p < 0.05:
                    S_new[i, j] = SS
                else:
                    S_new[i, j] = np.nan 
    
    N_ = df[:, :mid-star+1]
    N = np.reshape(N_, (df.shape[0]*(mid-star+1), df.shape[2], df.shape[3]))
    N = np.std(N, axis=0)
   
    N[N == 0] = np.nan 
    N = np.where((N < 0.00001) &( N > -0.00001), np.nan, N)
    
    S_new = np.absolute(S_new)
    emer = 2*N/S_new 
    emer[emer == inf] = np.nan
    
    return emer, N, S_new
    
def emerg(f_in, f_out, star, mid, end, model, name):
    resol = ['2_2', '5_5', '10_10', '20_20', '30_30',
             '45_45', '60_60'] 
    
    #remeber that "2_2" represents the resolution of 2.5x2.5
    if not os.path.isdir(f_out + model):
        os.mkdir(f_out + model)
       
    for k in resol:
        df = cmip_emeg_pixel(f_in, f_out, k, star, mid, end, model, name)
        emer, N, S_new = s_n_cal(df, star, mid)
        sign = ['time_emergence', 'noise', 'signal']
        n = 0
        for p in [emer, N, S_new]:
            with open(f_out + model + '/{}_distribution_{}_{}_{}_{}_{}.npy'.format(name, star, end, model, k, sign[n]), 'wb') as file:
                np.save(file, p)
            n += 1
    
            emer[emer == inf] = np.nan
            emer = emer + mid + 1
            
            fig, axs = plt.subplots(subplot_kw={'projection':ccrs.Robinson(central_longitude=180)},
                                    figsize=(10, 8))
            cmap = mpl.cm.jet
            cmap = mpl.cm.hsv
            
            if k == '2_2':
                lon = np.arange(0, 358, 2.5)
                lat = np.arange(-89.5, 90, 2.5)
                # lat[:] = lat[::-1]
            else:
                lon = np.arange(0, 360, int(k.split('_')[1]))
                lat = np.arange(-85.5, 91, int(k.split('_')[0]))
                # lat[:] = lat[::-1]
            # S_new, lon = add_cyclic_point(S_new, coord=lon)
            
            cs= axs.contourf(lon, lat, S_new, cmap=cmap, alpha=0.7,
                            transform=ccrs.PlateCarree())
            axs.set_global()
            axs.coastlines(alpha=0.4)
            cbar_ax = fig.add_axes([0.2, 0.2, 0.6, 0.02])
            cbar = fig.colorbar(cs, cax=cbar_ax, orientation='horizontal')
            cbar.set_label('Slope of ensemble mean, {}, gC/m2/year'.format(model), size=14)
            plt.savefig(f_out + model + '/{}_slope_{}_{}_{}_{}.png'.format(name, star, end, model, k), bbox_inches='tight', dpi=300)
           
            fig, axs = plt.subplots(subplot_kw={'projection':ccrs.Robinson(central_longitude=180)},
                                    figsize=(10, 8))
            cmap = mpl.cm.RdBu
            cmap = mpl.cm.hsv
            cs= axs.contourf(lon, lat, N, cmap=cmap, alpha=0.7,
                                transform=ccrs.PlateCarree())
            axs.set_global()
            axs.coastlines(alpha=0.4)
            cbar_ax = fig.add_axes([0.2, 0.2, 0.6, 0.02])
            cbar = fig.colorbar(cs, cax=cbar_ax, orientation='horizontal')
            cbar.set_label('std ensembles, 1930-1959, {}, gC/m2'.format(model), size=14)
            plt.savefig(f_out + model + '/{}_std_{}_{}_{}_{}.png'.format(name, star, end, model, k), bbox_inches='tight', dpi=300)
            
            fig, axs = plt.subplots(subplot_kw={'projection':ccrs.Robinson(central_longitude=180)},
                                    figsize=(10, 8))
            cmap = mpl.cm.RdBu
            cmap = mpl.cm.rainbow
            # levs = np.arange(mid+1, int(np.nanmax(emer))+2, 5)
            # cs= axs.contourf(lon, lat, emer, levs, cmap=cmap, alpha=0.7,
            #                     transform=ccrs.PlateCarree())
            
            cs= axs.contourf(lon, lat, emer, cmap=cmap, alpha=0.7,
                                transform=ccrs.PlateCarree())
            axs.set_global()
            axs.coastlines(alpha=0.4)
            cbar_ax = fig.add_axes([0.2, 0.2, 0.6, 0.02])
            cbar = fig.colorbar(cs, cax=cbar_ax, orientation='horizontal')
            cbar.set_label('Time of emergence, {}'.format(model), size=14)
            plt.savefig(f_out + model + '/{}_distribution_{}_{}_{}_{}_time_emergence.png'.format(name, star, end, model, k), bbox_inches='tight', dpi=300)
            
def emer_global(f_in, f_out, star, mid, end, name):
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    df_e = {}
    df_s = {}
    df_n = {}
    for model in code:
        print(f_in)
        df = cmip_emeg_pixel(f_in, f_out, 'global', star, mid, end, model, name)
        
        emer, N, S_new = s_n_cal(df, star, mid)
        print(emer.shape)
        df_e[model] = emer[0][0]
        df_s[model] = S_new[0][0]
        df_n[model] = N[0][0]
    
    df = [df_e, df_s, df_n]
    print(df_e)
    dff = ['emergence', 'signal', 'noise']
    for k in range(len(df)):
        df_f = pd.DataFrame(df[k], index=[dff[k]])
        df_f.to_csv(f_out + '{}_{}_{}_global.csv'.format(name, 'history', dff[k]))


def emer_global_RR(f_in, f_out, star, mid, end, name):
    
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    seas = ['djf', 'mam']
    
    for s in seas:
        df_e = {}
        df_s = {}
        df_n = {}
        for model in code:
            for i in [i for i in os.listdir(f_in) if i.endswith('resi.csv') 
                      and i.split('_')[3]==model and i.split('_')[4]==s]:
                print(i)
                model = i.split('_')[-6]
                if not os.path.isdir(f_out + model):
                    os.mkdir(f_out + model)
                
                df = os.path.join(f_in, i)
                df = pd.read_csv(df)
                date = np.arange(1851, 2015)
                inde1 = np.argwhere(date==star)
                inde3 = np.argwhere(date==end)
            
                df = np.asarray(df).reshape(-1, 164, 1, 1)
                df = df[:, inde1[0][0]:inde3[0][0]+1]
                emer, N, S_new = s_n_cal(df, star, mid)
                
                df_e[model] = emer[0][0]
                df_s[model] = S_new[0][0]
                df_n[model] = N[0][0]
        
        df = [df_e, df_s, df_n]
        print(df[0])
        print('--------------')
        dff = ['emergence', 'signal', 'noise']
        for k in range(len(df)):
            
            df_f = pd.DataFrame(df[k], index=[s])
            df_f.to_csv(f_out + 'RR_{}_{}_{}_{}_resi.csv'.format(name, 'history', dff[k], s))
        

if __name__ == '__main__':
    f_out = '.../results/'
    f_nbp = '.../data/nbp/'
    f_gpp = '.../data/gpp/'
    f_res = '.../data/res/'
    f_nbp_resi = '.../results/RR/history/nbp/'
    f_gpp_resi = '.../results/RR/history/gpp/'
    
    star, mid, end = 1930, 1959, 2009
    
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    # for i in code:
    #     print(i)
    #     emerg(f_nbp, f_out + 'emerge/nbp_emer/', star, mid, end, i, 'nbp')
    #     emerg(f_gpp, f_out + 'emerge/gpp_emer/', star, mid, end, i, 'gpp') 
    #     emerg(f_res, f_out + 'emerge/res_emer/', star, mid, end, i, 'res') 
    
    # emer_global(f_nbp, f_out + 'emerge/nbp_emer/', star, mid, end, 'nbp')
    # emer_global(f_gpp, f_out + 'emerge/gpp_emer/', star, mid, end, 'gpp')  
    # emer_global(f_res, f_out + 'emerge/res_emer/', star, mid, end, 'res')  
    
    # emer_global_RR(f_nbp_resi, f_out + 'emerge/nbp_emer_RR/', star, mid, end, 'nbp')
    # emer_global_RR(f_gpp_resi, f_out + 'emerge/gpp_emer_RR/', star, mid, end, 'gpp')
      
    
     