#!/bin/bash


f_in="/climca/data/cmip6-ng/psl/mon/g025/*"
f_out="/climca/people/lina/3rd_year_research/data/psl"
declare -a Model_list=("ACCESS-ESM1-5" "IPSL-CM6A-LR" "MPI-ESM1-2-LR")


for mode in ${Model_list[@]}
do
	echo $mode
done

same_str="_historical"

for mode in ${Model_list[@]}
do
n=0
for f in $f_in
do 	
	if echo "$f" | grep -q "$mode$same_str"
	then 	
			if echo "$f" | grep -q "i1p1" 
then 
	echo "$f" >> /climca/people/lina/3rd_year_research/data/psl/code_list_all.csv; 
	n=$(( n + 1))
#        cp $f $f_out
fi
	fi
done
echo $n
done

m=0
for f in $f_in
do 	
	if echo "$f" | grep -q "CanESM5_historical"
	then 	
       
		if echo "$f" | grep -q "i1p2" 
then 
	echo "$f" >> /climca/people/lina/3rd_year_research/data/psl/code_list_all.csv; 
	m=$(( m + 1))
#        cp $f $f_out     
fi
	fi
done
echo $m
