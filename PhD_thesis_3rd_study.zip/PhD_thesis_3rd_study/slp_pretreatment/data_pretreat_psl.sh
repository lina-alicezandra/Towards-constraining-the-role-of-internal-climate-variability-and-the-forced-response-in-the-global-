#! /bin/bash

# pre-treatment steps for CMIP6:
# unit kg m-2 s-1
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. year * 1000 convert to gC/m2/year
# 4. remap to 
# shape   df_grid        resolution
# 144x72  df_grid=1,1    2.5x2.5 remeber it can only show 2 not 2.5
# 72x36   df_grid=2,2    5 x 5
# 36x18   df_grid=4,4    10x10
# 18x9    df_grid=8,8    20x20
# 12x6    df_grid=12,12  30x30
# 8x4     df_grid=18,18  45x45
# 6x3     df_grid=24,24  60x60
# 1x1     df_grid=144,72 360x180    

# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area, this is 
# achieved by CDO fldmean/remapcon, which automatically area-weighting

#.......... remember that MPI has three more simulations 31-40, 48, 49, 50, we remove it later................

get_data () {

varia=$1
df_shape1=$2
df_shape2=$3

echo "r"$df_shape1"x"$df_shape2

res1=$(expr 360 / $df_shape1 | bc )
res2=$(expr 180 / $df_shape2 | bc )
echo $res1 
echo $res2 

f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_code_list=$f_out"code_list_all.csv"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"

mkdir $f_out"$res1""_""$res2"
echo $f_out"$res1""_""$res2" 
echo $f_code_list
echo $f_out
echo $f_temp

while read line
do
    echo $line
    df1=$(echo $line| cut -d'_' -f 2-5)
    df_out=$(echo $f_out"$res1""_""$res2"/"$varia""_"$df1"_""$res1""_""$res2.nc")
    echo $df_out
    
    cdo -remapcon,"r"$df_shape1"x"$df_shape2 $line $df_out

done < $f_code_list
rm $f_temp 

}

declare -a vari=("psl")
for va in ${vari[@]}
do

# get_data $va 72 36
get_data $va 36 18

done




