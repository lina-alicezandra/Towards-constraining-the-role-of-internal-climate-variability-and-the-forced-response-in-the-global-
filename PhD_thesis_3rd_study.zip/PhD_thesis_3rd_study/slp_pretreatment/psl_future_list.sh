#!/bin/bash


f_in="/climca/data/cmip6-ng/psl/mon/g025/*"
f_out="/climca/people/lina/3rd_year_research/data/psl_future"
declare -a Model_list=("ACCESS-ESM1-5" "IPSL-CM6A-LR" "MPI-ESM1-2-LR")


get_psl_list () {

same_str=$1
for mode in ${Model_list[@]}
do
echo $mode
n=0
for f in $f_in
do 	
	if echo "$f" | grep -q "$mode$same_str"
	then 	
			if echo "$f" | grep -q "i1p1" 
then 
	str=$(echo $same_str| cut -c1-7)
	echo "$f" >> /climca/people/lina/3rd_year_research/data/psl_future/code_list_all$str.csv; 
	n=$(( n + 1))
#        cp $f $f_out
fi
	fi
done
echo $n
done


m=0
for f in $f_in
do 	
	if echo "$f" | grep -q "CanESM5"$same_str
	then 	
       
		if echo "$f" | grep -q "i1p2" 
then 
	str=$(echo $same_str| cut -c1-7)
	echo "$f" >> /climca/people/lina/3rd_year_research/data/psl_future/code_list_all$str.csv; 
	m=$(( m + 1))
#        cp $f $f_out     
fi
	fi
done
echo $m

}

get_psl_list "_ssp126_"
get_psl_list "_ssp245_"
get_psl_list "_ssp370_"
get_psl_list "_ssp585_"

