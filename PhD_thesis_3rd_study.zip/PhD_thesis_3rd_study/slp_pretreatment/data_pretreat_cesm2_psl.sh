#! /bin/bash

# pre-treatment steps for CESM2:
# unit Pa

# 1. remap to 
# shape   df_grid        resolution
# 72x36   df_grid=2,2    5 x 5

# this is calculate mean slp, achieved by CDO fldmean, 
# this function automatically area-weighting, this is achived by CDO remapcon

get_data_cesm2 () {

varia=$1
df_shape1=$2
df_shape2=$3

res1=$(expr 360 / $df_shape1 | bc )
res2=$(expr 180 / $df_shape2 | bc )

echo $res1 
echo $res2 

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"


echo $f_out"$res1""_""$res2" 
echo $f_out


for line in $f_in/*historical*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 3-6)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out"$res1""_""$res2"/"$varia""_ann_"$df3"_""$res1""_""$res2.nc")
    echo $df_out
    
    cdo -remapcon,"r"$df_shape1"x"$df_shape2 $line $df_out

done 
rm $f_temp 


}

declare -a vari=("psl")
for va in ${vari[@]}
do
# get_data_cesm2 $va 72 36
get_data_cesm2 $va 36 18
done


