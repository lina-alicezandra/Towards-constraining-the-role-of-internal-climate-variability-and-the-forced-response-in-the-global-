#! /bin/bash

# pre-treatment steps for CMIP6:
# unit kg m-2 s-1
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. year * 1000 convert to gC/m2/year

# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area, this is 
# achieved by CDO fldmean, which automatically area-weighting

get_future_data () {
varia=$1
code=$2 
df_shape1=$3
df_shape2=$4

echo "r"$df_shape1"x"$df_shape2
res1=$(expr 360 / $df_shape1 | bc )
res2=$(expr 180 / $df_shape2 | bc )
echo $res1 
echo $res2 

add="_future"

f_out="/climca/people/lina/3rd_year_research/data/$varia$add/"
f_code_list=$f_out"code_list_all_$code.csv"

echo $f_code_list
f_temp="/climca/people/lina/3rd_year_research/data/$varia$add/""$varia$add""_ann_temp_.nc"

# mkdir $f_out"$res1""_""$res2"
mkdir $f_out"$code"
echo $f_code_list
echo $f_out
echo $f_temp

while read line
do
    echo $line
    df1=$(echo $line| cut -d'_' -f 2-5)
    df_out=$(echo $f_out"$code"/"$varia""_"$df1"_""$res1""_""$res2.nc")
    echo $df_out
    
    cdo -remapcon,"r"$df_shape1"x"$df_shape2 $line $df_out
    
done < $f_code_list
rm $f_temp 

}

declare -a vari=(psl)
declare -a scen=(ssp126 ssp245 ssp370 ssp585)
for va in ${vari[@]}
do

for sc in ${scen[@]}
do
get_future_data $va $sc 36 18

done
done