# !/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

This file create the package of
    1. take seasonal mean and sepearate into DJF, MAM, DJF+MAM
    2. Ridge regression leave one out 
This file is replicated from https://doi.org/10.17617/3.DMUQZY (Li, 2022).

"""

import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.linear_model import Ridge
from sklearn import preprocessing
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import RidgeCV


class SeasonFilter:
    
    def __init__(self, pressure, carbon):
        self.pressure = pressure
        self.carbon = carbon
    
    def inde_season(self, number):  
        indes = []
        for i in range(len(self.pressure)//12): 
            indes.append(i*12+number)
            indes.append(i*12+number+1)
            indes.append(i*12+number+2)         
        return indes  
    
    def inde_season_cesm(self, number):  
        indes = []
        for i in range(1 + len(self.pressure)//12): 
            indes.append(i*12+number)
            indes.append(i*12+number+1)
            indes.append(i*12+number+2)         
        return indes  
    
    def seas_filt(self, inde):  
        pre_d = np.array(self.pressure[inde].values) 
        season = np.zeros((pre_d.shape[0]//3, pre_d.shape[1], pre_d.shape[2]))
        for i in range(len(pre_d)//3):
            season[i] = pre_d[3*i : 3* (i+1)].mean(axis=0) 
        season = season.reshape(len(season), (season.shape[1]) * season.shape[2])
        return season 
    
    # def seas_filt(self, inde):  
    #     pre_d = np.array(self.pressure[inde]) 
    #     if pre_d.shape[1] != 1:
    #         season = np.zeros(((pre_d.shape[0]//3), pre_d.shape[1], pre_d.shape[2]))
    #     else:
    #         season = np.zeros(((pre_d.shape[0]//3)))
            
    #     for i in range(len(pre_d)//3):
    #         season[i] = pre_d[3*i : 3* (i+1)].mean(axis=0) 
    #     return season 

    
    def season(self):
        seas = {}
        num = [11, 2, 5, 8]
        seas['djf'] = self.inde_season(num[0])[:-3]
        seas['mam'] = self.inde_season(num[1])[3:]
        seas['jja'] = self.inde_season(num[2])[3:]
        seas['son'] = self.inde_season(num[3])[3:]
        slp_djf = self.seas_filt(seas['djf'])
        slp_mam = self.seas_filt(seas['mam'])
        slp_jja = self.seas_filt(seas['jja'])
        slp_son = self.seas_filt(seas['son'])
        return slp_djf, slp_mam, slp_jja, slp_son
    
    def season_cesm(self):
        seas = {}
        num = [10, 1, 4, 7]
        seas['djf'] = self.inde_season_cesm(num[0])[:-3]
        seas['mam'] = self.inde_season_cesm(num[1])[3:]
        seas['jja'] = self.inde_season_cesm(num[2])[3:]
        seas['son'] = self.inde_season_cesm(num[3])[3:]
        
        slp_djf = self.seas_filt(seas['djf'])
        slp_mam = self.seas_filt(seas['mam'])
        slp_jja = self.seas_filt(seas['jja'])
        slp_son = self.seas_filt(seas['son'])
        return slp_djf, slp_mam, slp_jja, slp_son
    
    def file_sea(self):
        djf, mam, jja, son = self.season()
        djf_mam = np.concatenate((djf, mam), axis=1)
        djf_mam_jja = np.concatenate((djf, mam, jja), axis=1)
        djf_all = np.concatenate((djf, mam, jja, son), axis=1)
       
        rr_djf = RidgeRegression(djf, self.carbon)
        rr_mam = RidgeRegression(mam, self.carbon)
        rr_jja = RidgeRegression(jja, self.carbon)
        rr_son = RidgeRegression(son, self.carbon)
        rr_dm = RidgeRegression(djf_mam, self.carbon)
        
        return rr_djf, rr_mam, rr_jja, rr_son, rr_dm
    
    def file_sea_cesm(self):
        djf, mam, jja, son = self.season_cesm()
        djf_mam = np.concatenate((djf, mam), axis=1)
        djf_mam_jja = np.concatenate((djf, mam, jja), axis=1)
        djf_all = np.concatenate((djf, mam, jja, son), axis=1)
       
        rr_djf = RidgeRegression(djf, self.carbon)
        rr_mam = RidgeRegression(mam, self.carbon)
        rr_jja = RidgeRegression(jja, self.carbon)
        rr_son = RidgeRegression(son, self.carbon)
        rr_dm = RidgeRegression(djf_mam, self.carbon)
        
        return rr_djf, rr_mam, rr_jja, rr_son, rr_dm
    
    def to_ridge(self):
        d_linear = {}
        r_te = {}
        d_pre = {}
    
        rr_djf, rr_mam, rr_jja, rr_son, rr_dm = self.file_sea()
        d_linear['djf'], d_pre['djf'], r_te['djf']= rr_djf.leave_one_out()
        d_linear['mam'], d_pre['mam'], r_te['mam']= rr_mam.leave_one_out()
        d_linear['jja'], d_pre['jja'], r_te['jja'] = rr_jja.leave_one_out()
        d_linear['son'], d_pre['son'], r_te['son'] = rr_son.leave_one_out()
        d_linear['djf_mam'], d_pre['djf_mam'], r_te['djf_mam'] = rr_dm.leave_one_out()
       
        return d_linear, d_pre, r_te
    
    def to_ridge_cesm(self):
        d_linear = {}
        r_te = {}
        d_pre = {}
    
        rr_djf, rr_mam, rr_jja, rr_son, rr_dm = self.file_sea_cesm()
        d_linear['djf'], d_pre['djf'], r_te['djf']= rr_djf.leave_one_out()
        d_linear['mam'], d_pre['mam'], r_te['mam']= rr_mam.leave_one_out()
        d_linear['jja'], d_pre['jja'], r_te['jja'] = rr_jja.leave_one_out()
        d_linear['son'], d_pre['son'], r_te['son'] = rr_son.leave_one_out()
        d_linear['djf_mam'], d_pre['djf_mam'], r_te['djf_mam'] = rr_dm.leave_one_out()
       
        return d_linear, d_pre, r_te
  
class RidgeRegression:
           
    def __init__(self, slp_sea, carbon):
        self.slp_sea = slp_sea
        self.carbon = carbon
        
    def stand(self, tx, ty, tsx, tsy):
        scaler1 = preprocessing.StandardScaler().fit(np.array(tx))
        scaler2 = preprocessing.StandardScaler().fit(np.array(ty))
        slp = scaler1.transform(tx)
        carb = scaler2.transform(ty)
        test_x = scaler1.transform(tsx)
        test_y = scaler2.transform(tsy)
        return slp, carb, test_x, test_y
   
    def leave_one_out(self):
        d_linear={}
        d_pre={}
        for i in range(len(self.carbon)):
            a = list(range(len(self.carbon)))
            if i == 0:
                a.remove(i)
                a.remove(i + 1)
            if i > 0 and i < len(self.carbon)-1:
                a.remove(i - 1)
                a.remove(i)
                a.remove(i + 1)
            if i == len(self.carbon) - 1:
                a.remove(i - 1)
                a.remove(i)
            
            tx = self.slp_sea[a]
            ty = self.carbon[a]
            tsx = self.slp_sea[i].reshape(1, -1)
            tsy = self.carbon[i].reshape(1, -1)
            slp, carb, test_x, test_y = self.stand(tx, ty, tsx, tsy)
            d_linear[i] = self.ridge_linear(slp, carb, test_x, test_y) 
            d_pre[i] = d_linear[i]['pre_y']
        car = (self.carbon - self.carbon.mean())/self.carbon.std()
        r_te = self.r_test(d_pre, car) 
        return d_linear, d_pre, r_te
    
    
    def cross_validation(self, tr, te):
     
        tx = self.slp_sea[:tr]
        ty = self.carbon[:tr]
        tsx = self.slp_sea[tr:te]
        tsy = self.carbon[tr:te]
        slp, carb, test_x, test_y = self.stand(tx, ty, tsx, tsy)
        d_linear = self.ridge_linear(slp, carb, test_x, test_y) 
        d_pre = d_linear['pre_y']
        return d_linear, d_pre
        
    def ridge_linear(self, tx, ty, tsx, tsy):
        # lam = np.arange(100,5900,200)
        # lam =  np.arange(10,2000, 20)/10 #teleconnection indices
        # lam = np.arange(100,3000,500) # for slide window (CESM, DGVMs, and AGR) global 15, 20 ,30, 40, 100
        
        # due to the CESM SLP with resolution of 5*5, and the rest use SLP with resolution of 9*9
        # so the tropical SLP in CESM have 8*72=576 and others tropical SLP have 4*40=160 predictors,
        # here the tropical slide window for CESM has longer range of lambda.
        
        # lam = np.arange(100,5900,200) # for slide window (CESM) tropical 15, 20, 30, 40, 100
        # lam = np.arange(10, 1000, 50) # for slide_window tropical (DGVMs and AGR) 15, 20, 30, 40 
        # lam = np.arange(10, 2000, 50) # for slide_window CESM 500 years (global and tropical)
        lam = np.arange(10, 300, 10) #for slide window CESM 2000 years (global and tropical)
        
        dic = {'cv_lam':[], 'r2_tr':[], 'r_tr': [], 'best_score_cv': [], 'coef':[], 'pre_y':[], 
               'mse_tr':[], 'r2_te':[], 'r_te': [], 'mse_te':[], 'p_te':[]}  
        clf_cv = RidgeCV(alphas=(lam), cv=5).fit(tx, ty) 
        lamb = clf_cv.alpha_
        clf = Ridge(alpha=lamb)
        clf.fit(tx, ty)
        pre_y = clf.predict(tsx)
        w = clf.coef_
        score_tr = sklearn.metrics.r2_score(ty, clf.predict(tx))
        r_tr, p = scipy.stats.pearsonr(ty[:, 0], clf.predict(tx)[:, 0])
        mse_tr = sklearn.metrics.mean_squared_error(ty, clf.predict(tx))
        dic['best_score_cv'].append(clf_cv.best_score_)
        dic['cv_lam'].append(lamb)
        dic['r2_tr'].append(score_tr)   
        dic['coef'].append(w) 
        if len(pre_y) == 1:
            dic['pre_y'].append(pre_y[0][0])
        if len(pre_y) != 1:
            dic['pre_y'].append(pre_y)
            dic['r2_te'].append(sklearn.metrics.r2_score(tsy, clf.predict(tsx)))
            r1, p1= scipy.stats.pearsonr(tsy[:, 0], clf.predict(tsx)[:, 0])
            dic['r_te'].append(r1)
            dic['p_te'].append(p1)
            dic['mse_te'].append(sklearn.metrics.
                                  mean_squared_error(tsy, clf.predict(tsx))) 
        dic['r_tr'].append(r_tr)  
        dic['mse_tr'].append(mse_tr)
        return dic
    
    def r_test(self, d_pre, carb):
        dic2 = {'mse_test':[], 'r2_test':[], 'r_test': [], 'p_test':[]}    
        d_pre2 = pd.DataFrame(d_pre)
        for i in range(len(d_pre2)):
            es = d_pre2.iloc[i]
            dic2['r2_test'].append(sklearn.metrics.r2_score(carb, es))
            r1, p1= scipy.stats.pearsonr(carb[:, 0], 
                                         np.asarray(es).reshape(-1, 1)[:, 0])
            dic2['r_test'].append(r1)
            dic2['p_test'].append(p1)
            dic2['mse_test'].append(sklearn.metrics.mean_squared_error(carb, es))
        return dic2
    
    def sanity_test(self):
        slp_sea = SeasonFilter(self.slp_sea, self.carbon)
        djf, mam, jja, son = slp_sea.season()
        x_tr, y_tr, x_te, y_te = self.stand(djf, self.carbon, djf, self.carbon)
        dic = self.ridge_linear(x_tr, y_tr, x_te, y_te)
        esti_y = dic['pre_y'][0]
        dic2 = self.ridge_linear(x_tr[:-4], esti_y[:-4], x_tr[-4:], esti_y[-4:])
        pre_y = dic2['pre_y'][0]
        return dic2

# if __name__ == '__main__':
    
    # run function
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
