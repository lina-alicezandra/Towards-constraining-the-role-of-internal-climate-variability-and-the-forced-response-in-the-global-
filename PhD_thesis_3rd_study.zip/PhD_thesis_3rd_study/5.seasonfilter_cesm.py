#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: nali@bgc-jena.mpg.de


This script is to filter out four seasons in CESM2-LE, this file is mostly replicated from https://doi.org/10.17617/3.DMUQZY (Li, 2022).

"""

import numpy as np

class SeasonFilter:
    
    def __init__(self, pressure):
        self.pressure = pressure
        
    def inde_season(self, number):  
        indes = []
        for i in range(len(self.pressure)//12): 
            indes.append(i*12+number)
            indes.append(i*12+number+1)
            indes.append(i*12+number+2)         
        return indes 
    
    def inde_season_cesm(self, number):  
        indes = []
        for i in range(1 + len(self.pressure)//12): 
            indes.append(i*12+number)
            indes.append(i*12+number+1)
            indes.append(i*12+number+2)         
        return indes 
    
    def seas_filt(self, inde):  
        pre_d = np.array(self.pressure[inde]) 
        if pre_d.shape[1] != 1:
            season = np.zeros(((pre_d.shape[0]//3), pre_d.shape[1], pre_d.shape[2]))
        else:
            season = np.zeros(((pre_d.shape[0]//3)))
            
        for i in range(len(pre_d)//3):
            season[i] = pre_d[3*i : 3* (i+1)].mean(axis=0) 
        return season 

    
    def season(self):
        seas = {}
        num = [11, 2, 5, 8]
        seas['djf'] = self.inde_season(num[0])[:-3]
        seas['mam'] = self.inde_season(num[1])[3:]
        seas['jja'] = self.inde_season(num[2])[3:]
        seas['son'] = self.inde_season(num[3])[3:]
        
        slp_djf = self.seas_filt(seas['djf'])
        slp_mam = self.seas_filt(seas['mam'])
        slp_jja = self.seas_filt(seas['jja'])
        slp_son = self.seas_filt(seas['son'])
        return slp_djf, slp_mam, slp_jja, slp_son
    
    
    def season_cesm(self):
        seas = {}
        num = [10, 1, 4, 7]
        seas['djf'] = self.inde_season_cesm(num[0])[:-3]
        seas['mam'] = self.inde_season_cesm(num[1])[3:]
        seas['jja'] = self.inde_season_cesm(num[2])[3:]
        seas['son'] = self.inde_season_cesm(num[3])[3:]
        
        slp_djf = self.seas_filt(seas['djf'])
        slp_mam = self.seas_filt(seas['mam'])
        slp_jja = self.seas_filt(seas['jja'])
        slp_son = self.seas_filt(seas['son'])
        
        return slp_djf, slp_mam, slp_jja, slp_son
    

    
    
if __name__ == '__main__':
    f = '.../research/'
    

    
    
