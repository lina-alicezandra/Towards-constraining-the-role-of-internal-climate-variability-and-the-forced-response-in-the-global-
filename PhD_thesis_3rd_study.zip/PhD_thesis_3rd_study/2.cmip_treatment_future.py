# This is to calculate the time of emergence of global scale in future scenarios.

# for noise period is 2020-2050, with ensemble mean removed. signal period is 2020-2070
# remember that when comparing the time of emergence between original and RR predicted NBP/GPP, the RR predicted has
# several simulations missing, details check run_ridge.py

import scipy
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import matplotlib as mpl
import scipy.stats
from numpy import inf
import cartopy.crs as ccrs
from cmip_treatment import cmip_emeg_pixel, linear_regre


def s_n_cal_fut(df, star, mid):
    print('this df shape {}'.format(df.shape))
    print(star, mid)
    
    # if model == 'MPI-ESM1-2-LR' and scena == 'ssp370':
    #     print(df[5])
    if np.all(df==0):
        print(df)
        
    S = np.mean(df, axis=0)[:51].ravel()
    SS, r, p = linear_regre(np.arange(len(S)), S)
    if p < 0.05:
        S_new = SS
    else:
        
        S_new = np.nan 
    
    N_ = df[:, :mid-star+1]
    N_ = N_ - np.mean(N_, axis=0)
    
    N = np.reshape(N_, (df.shape[0]*(mid-star+1)))
    N = np.std(N, axis=0)
   
    N = np.where((N < 0.00001) &( N > -0.00001), np.nan, N).ravel()
    
    S_new = np.absolute(S_new)
    emer = 2*N/S_new 
    emer[emer == inf] = np.nan
    return emer, N, S_new
    
def emerg_future(f_in, f_out, star, mid, end, name):
    
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    df_e = {}
    df_s = {}
    df_n = {}
    for model in code:
        if not os.path.isdir(f_out + model):
            os.mkdir(f_out + model)
            print(f_out + model)
        if model == 'CESM2-LE':
            scen = ['ssp370']
        else:
            scen = ['ssp126', 'ssp245', 'ssp370', 'ssp585'] 
        # scen = ['ssp126', 'ssp245', 'ssp370', 'ssp585'] 
        #remeber that "2_2" represents the resolution of 2.5x2.5
        
        e = np.zeros((4))
        s = np.zeros((4))
        n = np.zeros((4))
        for i in range(len(scen)):
            
            df = cmip_emeg_pixel(f_in, f_out, scen[i], star, mid, end, model, name)
            
            emer, N, S_new = s_n_cal_fut(df, star, mid)
            
            if model == 'CESM2-LE':
                e[2] = emer[0]
                s[2] = S_new
                n[2] = N[0]
            else:
                e[i] = emer[0]
                s[i] = S_new
                n[i] = N[0]
                
        df_e[model] = e
        df_s[model] = s
        df_n[model] = n
        
    df = [df_e, df_s, df_n]
    print(df_e)
    dff = ['emergence', 'signal', 'noise']
    for k in range(len(df)):
        df_f = pd.DataFrame(df[k], index=scen)
        df_f.to_csv(f_out + '{}_{}_{}_global.csv'.format(name, 'future', dff[k]))


def emerg_RR_future(f_in, f_out, star, mid, end, name):

    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    seas = ['djf', 'mam']
    for se in seas:
        df_e = {}
        df_s = {}
        df_n = {}
        for model in code:
            date = np.arange(2016, 2101)
            if model == 'CESM2-LE':
                scen = ['ssp370']
            else:
                scen = ['ssp126', 'ssp245', 'ssp370', 'ssp585'] 
            
            #remeber that "2_2" represents the resolution of 2.5x2.5
            e = np.zeros((4))
            s = np.zeros((4))
            n = np.zeros((4))
            for k in range(len(scen)):
                print(scen[k])
                print(se)
                for i in [i for i in os.listdir(f_in + scen[k] +'/') if i.endswith('resi.csv') and
                            i.split('_')[3] == model and i.split('_')[5] == se]:
                    
                    file = pd.read_csv(os.path.join(f_in + scen[k] + '/', i))
                    df = np.asarray(file).reshape(-1, len(date))
                    inde_star = np.argwhere(date==star)
                    inde_end = np.argwhere(date==end)
                    
                    df2 = df[:, inde_star[0][0]:inde_end[0][0]+1]
                    df2 = np.expand_dims(df2, (2, 3))
                    emer, N, S_new = s_n_cal_fut(df2, star, mid)
                    print(emer)
                    print(e)
                    if model == 'CESM2-LE':
                        e[2] = emer[0]
                        s[2] = S_new
                        n[2] = N[0]
                    else:
                        e[k] = emer[0]
                        s[k] = S_new
                        n[k] = N[0]
            df_e[model] = e
            df_s[model] = s
            df_n[model] = n
            
        df = [df_e, df_s, df_n]
        print(df_e)
        dff = ['emergence', 'signal', 'noise']
        for k in range(len(df)):
            df_f = pd.DataFrame(df[k], index=scen)
            df_f.to_csv(f_out + 'RR_{}_{}_{}_{}_global.csv'.format(name, 'future', dff[k], se))
        
                
            
if __name__ == '__main__':
    f_out = '.../results/'
    f_nbp_future = '.../data/nbp_future/'
    f_gpp_future = '.../data/gpp_future/'
    f_res_future = '.../data/res_future/'
    
    f_nbp_pre_fut = ".../results/RR/future/nbp/"
    f_gpp_pre_fut = ".../results/RR/future/gpp/"
    
    star, mid, end = 2020, 2050, 2100
    
    # emerg_future(f_nbp_future, f_out + 'emerge/nbp_future_emer/', star, mid, end, 'nbp')        
    # emerg_future(f_gpp_future, f_out + 'emerge/gpp_future_emer/', star, mid, end, 'gpp')
    # emerg_future(f_res_future, f_out + 'emerge/res_future_emer/', star, mid, end, 'res')
    
    # emerg_RR_future(f_nbp_pre_fut, f_out + 'emerge/nbp_future_emer_RR/', star, mid, end, 'nbp')        
    # emerg_RR_future(f_gpp_pre_fut, f_out + 'emerge/gpp_future_emer_RR/', star, mid, end, 'gpp')        
       
     