#!/bin/bash

# remember to remove old code list first



get_list () {

varia=$1

f_in="/climca/data/cmip6-ng/$varia/ann/g025/*"
f_out="/climca/people/lina/3rd_year_research/data/$varia"
f_list="/climca/people/lina/3rd_year_research/data/$varia/code_list_all.csv"
declare -a Model_list=("ACCESS-ESM1-5" "IPSL-CM6A-LR" "MPI-ESM1-2-LR")

for mode in ${Model_list[@]}
do
	echo $mode
done

if [ $f_list ]
then
	echo "the list file exists"
	rm $f_list
fi

same_str="_historical"

for mode in ${Model_list[@]}
do
n=0
for f in $f_in
do 	
	if echo "$f" | grep -q "$mode$same_str"
	then 	
			if echo "$f" | grep -q "i1p1" 
then 
	echo "$f" >> $f_list; 
	n=$(( n + 1))
#        cp $f $f_out
fi
	fi
done
echo $n
done


m=0
for f in $f_in
do 	
	if echo "$f" | grep -q "CanESM5_historical"
	then 	
       
		if echo "$f" | grep -q "i1p2" 
then 
	echo "$f" >> $f_list; 
	m=$(( m + 1))
#        cp $f $f_out     
fi
	fi
done
echo $m

}

# declare -a vari=(nbp gpp ra ra tsa)
declare -a vari=(nbp)
for va in ${vari[@]}
do
get_list $va 
done
