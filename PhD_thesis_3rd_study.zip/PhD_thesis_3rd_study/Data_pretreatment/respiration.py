#This is for the PhD thesis chapter 4 Constraining the time of emergence of anthropogenic signal #in global land carbon sink

#Author nali@bgc-jena.mpg.de
# This file is to calculate TER.


import scipy
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import matplotlib as mpl
import scipy.stats
from numpy import inf
from cmip_treatment import order_file


def res_cmip6(f_ra, f_rh, f_out, domain, period):
    code = ['ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    
    date = np.arange(1851, 2015)
    if not os.path.isdir(f_out): 
        os.mkdir(f_out)
    for i in code:
        df_ra = order_file(f_ra, i, domain, 'ra')
        df_rh = order_file(f_rh, i, domain, 'rh')
        
        if domain == 'global':
            inde = -2
        elif domain == '2_2':
            lat = int(180//2.5)
            lon = int(360//2.5)
            print(lat, lon)
            inde = -3
        else:
            lat = int(180//int(domain.split('_')[0]))
            lon = int(360//int(domain.split('_')[0]))
            inde = -3
        
        n = 0
        for j in df_ra:
            for k in [k for k in df_rh if k.split('_')[inde]==j.split('_')[inde]]:
                d_ra = xr.open_dataset(j)
                d_rh = xr.open_dataset(k)
                
                d_ra = d_ra.sel(time=slice('1851-01-01', '2014-12-31'))
                d_rh = d_rh.sel(time=slice('1851-01-01', '2014-12-31'))
                
                d_ra = d_ra.ra
                d_rh = d_rh.rh
                # if n == 26:
                #     print(d_ra[26].values)
                #     print(d_rh[26].values)
                d_r = d_ra + d_rh
                if np.isnan(d_r.values).all() or np.all(d_r.values == 0):
                    print(j)
                else:
                    d_r = d_r.rename('res')
                    d_r.to_netcdf(f_out + 'res_ann_{}_historical_{}_{}.nc'.format(i, j.split('_')[inde], domain))
            
            n += 1

def res_cesm2(f_npp, f_gpp, f_litter, f_soil, f_out, domain, period):
    
    df_npp = order_file(f_npp, 'CESM2-LE', domain, 'npp')
    df_gpp = order_file(f_gpp, 'CESM2-LE', domain, 'gpp')
    
    if not os.path.isdir(f_out): 
        os.mkdir(f_out)
    
    if domain == 'global':
        inde = -2
    elif domain == '2_2':
        lat = int(180//2.5)
        lon = int(360//2.5)
        print(lat, lon)
        inde = -3
    else:
        lat = int(180//int(domain.split('_')[0]))
        lon = int(360//int(domain.split('_')[0]))
        inde = -3
    
    n = 0
    for j in df_npp:
        print(j)
        for k in [k for k in df_gpp if k.split('_')[inde]==j.split('_')[inde]]:
            print(k)
            for l in [l for l in sorted(os.listdir(f_litter+domain+'/')) if l.split('_')[inde]==j.split('_')[inde]]:
                print(l)
                for m in [m for m in sorted(os.listdir(f_soil+domain+'/')) if m.split('_')[inde]==j.split('_')[inde]]:
                    print(m)
            
                    d_npp = xr.open_dataset(j)
                    d_gpp = xr.open_dataset(k)
                    d_litt = xr.open_dataset(os.path.join(f_litter+domain+'/', l))
                    d_soil = xr.open_dataset(os.path.join(f_soil+domain+'/', m))
                    
                    d_npp = d_npp.sel(time=slice('1851-01-01', '2014-12-31'))
                    d_gpp = d_gpp.sel(time=slice('1851-01-01', '2014-12-31'))
                    
                    d_litt = d_litt.sel(time=slice('1851-01-01', '2014-12-31'))
                    d_soil = d_soil.sel(time=slice('1851-01-01', '2014-12-31'))
                    
                    d_npp = d_npp.NPP
                    d_gpp = d_gpp.GPP
                    
                    d_litt = d_litt.LITTERC_HR
                    d_soil = d_soil.SOILC_HR
                    
                    d_r = d_gpp - d_npp + d_litt + d_soil
                    if np.isnan(d_r.values).all() or np.all(d_r.values == 0):
                        print(j)
                        
                    else:
                        d_r = d_r.rename('RES')
                        print(len(d_r.time))
                        if domain == 'global':
                            d_r.to_netcdf(f_out + 'res_ann_CESM2-LE_historical_{}_{}_{}.nc'.format(k.split('_')[-3], k.split('_')[-2], domain))
                        else:
                            d_r.to_netcdf(f_out + 'res_ann_CESM2-LE_historical_{}_{}_{}.nc'.format(k.split('_')[-4], k.split('_')[-3], domain))
        
        n += 1
    
            
def res_cmip6_fut(f_ra, f_rh, f_out, scenario, period):
    code = ['ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    if not os.path.isdir(f_out): 
        os.mkdir(f_out)
    date = np.arange(2016, 2101)
    for i in code:
        df_ra = order_file(f_ra, i, scenario, 'ra')
        df_rh = order_file(f_rh, i, scenario, 'rh')
        inde = -2
        
        n = 0
        for j in df_ra:
            for k in [k for k in df_rh if k.split('_')[inde]==j.split('_')[inde]]:
                d_ra = xr.open_dataset(j)
                d_rh = xr.open_dataset(k)
                
                d_ra = d_ra.sel(time=slice('2016-01-01', '2100-12-31'))
                d_rh = d_rh.sel(time=slice('2016-01-01', '2100-12-31'))
                
                d_ra = d_ra.ra
                d_rh = d_rh.rh
                # if n == 26:
                #     print(d_ra[26].values)
                #     print(d_rh[26].values)
                d_r = d_ra + d_rh
                if np.isnan(d_r.values).all() or np.all(d_r.values == 0):
                    print(j)
                else:
                    d_r = d_r.rename('res')
                    
                    d_r.to_netcdf(f_out + 'res_ann_{}_{}_{}_global.nc'.format(i, scenario, k.split('_')[-2]))
                
            n += 1

def res_cesm2_fut(f_npp, f_gpp, f_litter, f_soil, f_out, scenario, period):
    
    df_npp = order_file(f_npp, 'CESM2-LE', scenario, 'npp')
    df_gpp = order_file(f_gpp, 'CESM2-LE', scenario, 'gpp')
    date = np.arange(2016, 2101)
    if not os.path.isdir(f_out): 
        os.mkdir(f_out)
    for i in [i for i in df_gpp if i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:8]=='1251']:
        df_gpp.remove(i)        
    
    print(len(df_gpp))
    inde = -2
    n = 0
    print(len(df_npp))
    for j in df_npp:
        print(j)
        for k in [k for k in df_gpp if k.split('_')[inde]==j.split('_')[inde]]:
            print(k)
            for l in [l for l in sorted(os.listdir(f_litter+scenario+'/')) if l.split('_')[inde]==j.split('_')[inde]]:
                print(l)
                for m in [m for m in sorted(os.listdir(f_soil+scenario+'/')) if m.split('_')[inde]==j.split('_')[inde]]:
                    print(m)
                    print(k.split('_')[-2])
                    d_npp = xr.open_dataset(j)
                    d_gpp = xr.open_dataset(k)
                    d_litt = xr.open_dataset(os.path.join(f_litter+scenario+'/', l))
                    d_soil = xr.open_dataset(os.path.join(f_soil+scenario+'/', m))
                    
                    d_npp = d_npp.sel(time=slice('2016-01-01', '2100-12-31'))
                    d_gpp = d_gpp.sel(time=slice('2016-01-01', '2100-12-31'))
                    
                    d_litt = d_litt.sel(time=slice('2016-01-01', '2100-12-31'))
                    d_soil = d_soil.sel(time=slice('2016-01-01', '2100-12-31'))
                    
                    d_npp = d_npp.NPP
                    d_gpp = d_gpp.GPP
                    
                    d_litt = d_litt.LITTERC_HR
                    d_soil = d_soil.SOILC_HR
                    
                    d_r = d_gpp - d_npp + d_litt + d_soil
                    if np.isnan(d_r.values).all() or np.all(d_r.values == 0):
                        print(j)
                    else:
                        d_r = d_r.rename('RES')
                        
                        d_r.to_netcdf(f_out + 'res_ann_CESM2-LE_{}_{}_global.nc'.format(k.split('_')[-3], k.split('_')[-2]))
                
        n += 1
            
if __name__ == '__main__':
    f_out = '/climca/people/lina/3rd_year_research/data/res/'
    f_ra = '/climca/people/lina/3rd_year_research/data/ra/'
    f_rh = '/climca/people/lina/3rd_year_research/data/rh/'
    f_npp = '/climca/people/lina/3rd_year_research/data/npp/'
    f_gpp = '/climca/people/lina/3rd_year_research/data/gpp/'
    f_litter = '/climca/people/lina/3rd_year_research/data/litterc_hr/'
    f_soil = '/climca/people/lina/3rd_year_research/data/soilc_hr/'
    
    f_out2 = '/climca/people/lina/3rd_year_research/data/res_future/'
    f_ra_fut = '/climca/people/lina/3rd_year_research/data/ra_future/'
    f_rh_fut = '/climca/people/lina/3rd_year_research/data/rh_future/'
    f_npp_fut = '/climca/people/lina/3rd_year_research/data/npp_future/'
    f_gpp_fut = '/climca/people/lina/3rd_year_research/data/gpp_future/'
    f_litter_fut = '/climca/people/lina/3rd_year_research/data/litterc_hr_future/'
    f_soil_fut = '/climca/people/lina/3rd_year_research/data/soilc_hr_future/'
    
    
    # eco-respiration = GPP - NPP
    # res_cmip6(f_ra, f_rh, f_gpp, f_out, 'history')
    dom = ['2_2', '5_5', '10_10', '20_20', '30_30', '45_45', '60_60', 'global']
    dom = ['global']
    scen = ['ssp126', 'ssp245', 'ssp370', 'ssp585']
    
    for i in dom:
        print(i)
        res_cesm2(f_npp, f_gpp, f_litter, f_soil, f_out + i+'/', i, 'historical')
        res_cmip6(f_ra, f_rh,  f_out+i+'/', i, 'historical')
        
    for j in scen:
        res_cmip6_fut(f_ra_fut, f_rh_fut, f_out2+j+'/', j, 'future')
        
    res_cesm2_fut(f_npp_fut, f_gpp_fut, f_litter_fut, f_soil_fut, f_out2 + 'ssp370'+'/', 'ssp370', 'future')
