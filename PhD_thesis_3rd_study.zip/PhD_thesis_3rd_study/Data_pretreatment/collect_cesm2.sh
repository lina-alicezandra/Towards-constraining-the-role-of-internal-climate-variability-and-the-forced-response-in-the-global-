#! /bin/bash


f_area="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/nbp_ori/b.e21.BHISTcmip6.f09_g17.LE2-1001.001.clm2.h0.NBP.185001-185912.nc"
f_area_new="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/b.e21.BHISTcmip6.f09_g17.NBP.area.nc"

cdo -selname,area $f_area $f_area_new

data_sel_cesm2 () {

vari=$1

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/"$vari"_ori/"
f_out="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$vari/"

name=("BHISTcmip6" "BHISTsmbb")

# name=("BHISTcmip6")

name2=("BSSP370cmip6" "BSSP370smbb")
code=("LE2-1001.001" "LE2-1021.002" "LE2-1041.003" "LE2-1061.004" "LE2-1081.005" "LE2-1101.006" "LE2-1121.007" "LE2-1141.008"
"LE2-1161.009" "LE2-1181.010" "LE2-1011.001" "LE2-1031.002" "LE2-1051.003" "LE2-1071.004" "LE2-1091.005" "LE2-1111.006" "LE2-1131.007" 
"LE2-1151.008" "LE2-1171.009" "LE2-1191.010")

# code=("LE2-1061.004")

code2=("LE2-1231" "LE2-1251" "LE2-1281" "LE2-1301")
num=("001" "002" "003" "004" "005" "006" "007" "008" "009" "010"
"011" "012" "013" "014" "015" "016" "017" "018" "019" "020")

for na in ${name[@]}
do

for co in ${code[@]}
do
echo $na
echo $co
cdo -O -L -mergetime -apply,-selname,${vari^^} [ $f_in*.$na.*.$co.*.nc ]  $f_out$vari"_mon_CESM2-LE_historical_"$na"_"$co".nc" 

done

for coo in ${code2[@]}
do
for nu in ${num[@]} 
do
cdo -O -L -mergetime -apply,-selname,${vari^^} [ $f_in*.$na.*.$coo.$nu.*.nc ]  $f_out$vari"_mon_CESM2-LE_historical_"$na"_"$coo"."$nu".nc" 

done 
done
done

for na in ${name2[@]}
do

for co in ${code[@]}
do

cdo -O -L -mergetime -apply,-selname,${vari^^} [ $f_in*.$na.*.$co.*.nc ]  $f_out$vari"_mon_CESM2-LE_future_"$na"_"$co".nc" 

done

for coo in ${code2[@]}
do
for nu in ${num[@]} 
do
cdo -O -L -mergetime -apply,-selname,${vari^^} [ $f_in*.$na.*.$coo.$nu.*.nc ]  $f_out$vari"_mon_CESM2-LE_future_"$na"_"$coo"."$nu".nc" 

done 
done
done

}

# data_sel_cesm2 gpp
# data_sel_cesm2 nbp
# data_sel_cesm2 psl
# data_sel_cesm2 npp
# data_sel_cesm2 litterc_hr
# data_sel_cesm2 soilc_hr

