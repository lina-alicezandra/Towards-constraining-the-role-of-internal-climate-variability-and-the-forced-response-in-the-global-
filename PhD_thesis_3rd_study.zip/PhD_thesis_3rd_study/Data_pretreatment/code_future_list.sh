#!/bin/bash



get_future_list () {

varia=$1
same_str=$2

f_in="/climca/data/cmip6-ng/$varia/ann/g025/*"
f_out="/climca/people/lina/3rd_year_research/data/"$varia"_future"
declare -a Model_list=("ACCESS-ESM1-5" "IPSL-CM6A-LR" "MPI-ESM1-2-LR")

str=$(echo $same_str| cut -c1-7)
f_list="/climca/people/lina/3rd_year_research/data/"$varia"_future/code_list_all$str.csv"
# echo $f_list
# echo $varia

if [ $f_list ]
then
	echo "the list file exists"
	rm $f_list
fi

for mode in ${Model_list[@]}
do
echo $mode
n=0
for f in $f_in
do 	
	if echo "$f" | grep -q "$mode$same_str"
	then 	
			if echo "$f" | grep -q "i1p1" 
then 
	echo "$f" >> $f_list; 
	n=$(( n + 1))
#        cp $f $f_out
fi
	fi
done
echo $n
done


m=0
for f in $f_in
do 	
	echo "CanESM5"
	if echo "$f" | grep -q "CanESM5"$same_str
	then 	
       
		if echo "$f" | grep -q "i1p2" 
then 
	echo "$f" >> $f_list; 
	m=$(( m + 1))
#        cp $f $f_out     
fi
	fi
done
echo $m

}

# declare -a vari=(nbp gpp)
# for va in ${vari[@]}
# do

# get_future_list $va "_ssp126_"
# get_future_list $va "_ssp245_"
# get_future_list $va "_ssp370_"
# get_future_list $va "_ssp585_"

# done

declare -a vari=(ra rh)
for va in ${vari[@]}
do

get_future_list $va "_ssp126_"
get_future_list $va "_ssp245_"
get_future_list $va "_ssp370_"
get_future_list $va "_ssp585_"

done