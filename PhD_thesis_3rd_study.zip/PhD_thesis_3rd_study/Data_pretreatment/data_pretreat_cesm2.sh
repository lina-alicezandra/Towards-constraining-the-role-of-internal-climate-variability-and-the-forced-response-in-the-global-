#! /bin/bash

# pre-treatment steps for CESM2:
# unit gC m-2 s-1
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. the unit is gC/m2/year
# 4. remap to 
# shape   df_grid        resolution
# 144x72  df_grid=1,1    2.5x2.5 remeber it can only show 2 not 2.5
# 72x36   df_grid=2,2    5 x 5
# 36x18   df_grid=4,4    10x10
# 18x9    df_grid=8,8    20x20
# 12x6    df_grid=12,12  30x30
# 8x4     df_grid=18,18  45x45
# 6x3     df_grid=24,24  60x60
# 1x1     df_grid=144,72 360x180    

# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area, this is
# achieved by CDO fldmean/remapcon, this function automatically area-weighting

get_data_cesm2 () {

varia=$1
df_shape1=$2
df_shape2=$3

res1=$(expr 360 / $df_shape1 | bc )
res2=$(expr 180 / $df_shape2 | bc )

echo $res1 
echo $res2 

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"

# ls $f_in/*historical*.nc

mkdir $f_out"$res1""_""$res2"
echo $f_out"$res1""_""$res2" 
echo $f_out
echo $f_temp

for line in $f_in/*historical*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 3-6)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out"$res1""_""$res2"/"$varia""_ann_"$df3"_""$res1""_""$res2.nc")
    echo $df_out
    
    cdo -L -yearsum -muldpm -mulc,24 -mulc,3600 $line $f_temp
    cdo -L -remapcon,"r"$df_shape1"x"$df_shape2 $f_temp $df_out

done 
rm $f_temp 
rm $f_temp2

}

get_global_data_cesm2 () {

varia=$1
echo $varia
f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"

# ls $f_in/*historical*.nc

# mkdir $f_out"$res1""_""$res2" 
echo $f_out
echo $f_temp

for line in $f_in/*historical*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 3-6)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out"global"/"$varia""_ann_"$df3"_global.nc")
    echo $df_out
    
    cdo -L -yearsum -muldpm -mulc,24 -mulc,3600 $line $f_temp
    cdo -L -fldmean $f_temp $df_out

done 
rm $f_temp 

}



get_data_cesm2_litterc () {

varia=$1
df_shape1=$2
df_shape2=$3

res1=$(expr 360 / $df_shape1 | bc )
res2=$(expr 180 / $df_shape2 | bc )

echo $res1 
echo $res2 

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"

# ls $f_in/*historical*.nc

mkdir $f_out"$res1""_""$res2"
echo $f_out"$res1""_""$res2" 
echo $f_out
echo $f_temp

for line in $f_in/*historical*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 4-7)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out"$res1""_""$res2"/"$varia""_ann_"$df3"_""$res1""_""$res2.nc")
    echo $df_out
    
    cdo -L -yearsum -muldpm -mulc,24 -mulc,3600 $line $f_temp
    cdo -L -remapcon,"r"$df_shape1"x"$df_shape2 $f_temp $df_out

done 
rm $f_temp 
rm $f_temp2

}

get_global_data_cesm2_litterc () {

varia=$1
echo $varia
f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"

# ls $f_in/*historical*.nc

mkdir $f_out"global"
echo $f_out
echo $f_temp

for line in $f_in/*historical*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 4-7)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out"global"/"$varia""_ann_"$df3"_global.nc")
    echo $df_out
    
    cdo -L -yearsum -muldpm -mulc,24 -mulc,3600 $line $f_temp
    cdo -L -fldmean $f_temp $df_out

done 
rm $f_temp 

}


# declare -a vari=(npp)
# for va in ${vari[@]}
# do
# get_data_cesm2 $va 6 3
# get_data_cesm2 $va 8 4
# get_data_cesm2 $va 12 6
# get_data_cesm2 $va 18 9
# get_data_cesm2 $va 36 18
# get_data_cesm2 $va 72 36
# get_data_cesm2 $va 144 72
# done

# declare -a vari=(nbp gpp npp)
# for va in ${vari[@]}
# do
# get_global_data_cesm2 $va 
# done

# declare -a vari=(litterc_hr soilc_hr)
# for va in ${vari[@]}
# do
# get_global_data_cesm2_litterc $va 
# get_data_cesm2_litterc $va 144 72
# done

# declare -a vari=(litterc_hr soilc_hr)
# for va in ${vari[@]}
# do
# get_data_cesm2_litterc $va 6 3
# get_data_cesm2_litterc $va 8 4
# get_data_cesm2_litterc $va 12 6
# get_data_cesm2_litterc $va 18 9
# get_data_cesm2_litterc $va 36 18
# get_data_cesm2_litterc $va 72 36
# done


