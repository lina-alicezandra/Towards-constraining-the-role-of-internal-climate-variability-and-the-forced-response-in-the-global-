#! /bin/bash

# pre-treatment steps for CMIP6:
# unit kg m-2 s-1
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. year * 1000 convert to gC/m2/year
# 4. remap to 
# shape   df_grid        resolution
# 144x72  df_grid=1,1    2.5x2.5 remeber it can only show 2 not 2.5
# 72x36   df_grid=2,2    5 x 5
# 36x18   df_grid=4,4    10x10
# 18x9    df_grid=8,8    20x20
# 12x6    df_grid=12,12  30x30
# 8x4     df_grid=18,18  45x45
# 6x3     df_grid=24,24  60x60
# 1x1     df_grid=144,72 360x180    

# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area, this is 
# achieved by CDO fldmean/remapcon, which automatically area-weighting

# for access, 21 and 25 has no data

get_data () {

varia=$1
df_shape1=$2
df_shape2=$3

echo "r"$df_shape1"x"$df_shape2

res1=$(expr 360 / $df_shape1 | bc )
res2=$(expr 180 / $df_shape2 | bc )
echo $res1 
echo $res2 

f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_code_list=$f_out"code_list_all.csv"
# land_area="/climca/people/lina/3rd_year_research/data/area.ESACCI.144.72.nc"
land_area_new="/climca/people/lina/3rd_year_research/data/area.ESACCI.144.72_new.nc"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"
f_line2="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_2.nc"
f_mask1="/climca/data/cmip6-ng/masks/fx/native/sftlf000_fx_CanESM5_historical_r8i1p2f1_native.nc"
f_mask2="/climca/people/lina/3rd_year_research/data/mask_2.5.nc"
f_mask="/climca/people/lina/3rd_year_research/data/ocean_mask.nc"
f_ann="/climca/data/cmip6-ng/npp/ann/g025/npp_ann_CanESM5_historical_r10i1p1f1_g025.nc"

mkdir $f_out"$res1""_""$res2"
echo $f_out"$res1""_""$res2" 
echo $f_code_list
echo $f_out
echo $f_temp

while read line
do
    echo $line
    df1=$(echo $line| cut -d'_' -f 2-5)
    df_out=$(echo $f_out"$res1""_""$res2"/"$varia""_"$df1"_""$res1""_""$res2.nc")
    echo $df_out
# create ocean map
    model_name=$(echo $line| cut -d'_' -f 3)
    echo $model_name
    
    if echo "$model_name" | grep -q "CanESM5"
	then 	
			echo line
            cdo -remapnn,$f_ann $f_mask1 $f_mask2  
            cdo -setctomiss,0 -addc,1 -mulc,-1 $f_mask2 $f_mask
            
            cdo -L -muldpy -mulc,24 -mulc,3600 -select,name=$varia $line $f_temp
            cdo -mul $f_temp $f_mask $f_line2
            cdo -L -mulc,1000 -remapcon,"r"$df_shape1"x"$df_shape2 $f_line2 $df_out
    else
            cdo -L -muldpy -mulc,24 -mulc,3600 -select,name=$varia $line $f_temp
            cdo -L -mulc,1000 -remapcon,"r"$df_shape1"x"$df_shape2 $f_temp $df_out

    fi

    # cdo -L -divc,1000000000000 -gridboxsum,$df_grid -mul $f_temp $land_area_new $f_temp3
    # cdo -griddes $df_out
    # cdo -L -divc,1000000000000 -fldsum -mul $f_temp $land_area_new $f_temp2
    # cdo -gridboxsum,144,72 -setgridarea,$land_area_new $f_temp $df_out
    
done < $f_code_list
rm $f_temp
rm $f_line2 
rm $f_mask2

}


get_global_data () {
varia=$1
f_out="/climca/people/lina/3rd_year_research/data/$varia/"
f_code_list=$f_out"code_list_all.csv"
f_temp="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_.nc"
f_line2="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_2.nc"
f_mask1="/climca/data/cmip6-ng/masks/fx/native/sftlf000_fx_CanESM5_historical_r8i1p2f1_native.nc"
f_mask2="/climca/people/lina/3rd_year_research/data/mask_2.5.nc"
f_mask="/climca/people/lina/3rd_year_research/data/ocean_mask.nc"
f_ann="/climca/data/cmip6-ng/npp/ann/g025/npp_ann_CanESM5_historical_r10i1p1f1_g025.nc"


mkdir $f_out"global"
echo $f_code_list
echo $f_out
echo $f_temp

while read line
do
    echo $line
    df1=$(echo $line| cut -d'_' -f 2-5)
    df_out=$(echo $f_out"global"/"$varia""_""$df1""_global.nc")
    echo $df_out

    # create ocean map
    model_name=$(echo $line| cut -d'_' -f 3)
    echo $model_name
   

    if echo "$model_name" | grep -q "CanESM5"
    then 	
            echo line
            cdo -remapnn,$f_ann $f_mask1 $f_mask2  
            cdo -setctomiss,0 -addc,1 -mulc,-1 $f_mask2 $f_mask
            
            cdo -L -muldpy -mulc,24 -mulc,3600 -select,name=$varia $line $f_temp
            cdo -mul $f_temp $f_mask $f_line2
            cdo -L -mulc,1000 -fldmean $f_line2 $df_out
            
    else
            cdo -L -muldpy -mulc,24 -mulc,3600 -select,name=$varia $line $f_temp
            cdo -L -mulc,1000 -fldmean $f_temp $df_out

    fi


done < $f_code_list
break
rm $f_temp 
rm $f_line2 
rm $f_mask2

}


# declare -a vari=(nbp gpp)
# for va in ${vari[@]}
# do
# get_data $va 6 3
# get_data $va 8 4
# get_data $va 12 6
# get_data $va 18 9
# get_data $va 36 18
# get_data $va 72 36
# get_data $va 144 72
# done

# declare -a vari=(nbp gpp ra rh)
# for va in ${vari[@]}
# do
# get_global_data $va 
# done

# declare -a vari=(ra rh)
# for va in ${vari[@]}
# do
# get_data $va 6 3
# get_data $va 8 4
# get_data $va 12 6
# get_data $va 18 9
# get_data $va 36 18
# get_data $va 72 36
# # get_data $va 144 72
# done

