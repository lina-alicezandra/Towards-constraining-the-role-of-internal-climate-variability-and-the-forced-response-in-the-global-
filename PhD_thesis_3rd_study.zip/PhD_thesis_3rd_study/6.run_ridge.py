#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr 10 19:00:45 2021

@author: Na Li@nali@bgc-jena.mpg.de

This file use ridge regression to predict NBP and GPP.
   
"""

# note that ACCESS 21 and 25 has no data, we remove it
# slp in CESM2-LE starts 1850 02, in other models starts at 1850 01
# in CESM2-LE, some (nbp) BHISTsmbb has no LE2-1011-001 - 1191-010, we should always remove
# NBP MPI 8 has nan value
# for RR, 
# 1) NBP/GPP has ensemble mean removed, SLP kept the ensemble mean
# 2) the first half data is for training, the second half is for test. then switch the two, testing for training, 
# and training for testing, then we have the whole NBP/GPP predicted by RR.
# 3) the predicted NBP/GPP has back standrized by multiplying std(ori_nbp) + mean(ori_nbp)

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from ridge_regression import RidgeRegression
import xarray as xr
from seasonfilter_cesm import SeasonFilter
from cmip_treatment import order_file
    

def nbp_all(f_nbp, model, f_out, period, res, name):
    nbp = order_file(f_nbp, model, res, 'nbp')
    
    if nbp[0].split('_')[-3][:3] == 'ssp' or nbp[0].split('_')[-3][:4] == 'BSSP':
        date = np.arange(2016, 2101)
    else:
        date = np.arange(1851, 2015)
    code_list = []
    mean_all = np.zeros((len(nbp), len(date)))
    n = 0
    for i in nbp:
        
        df = xr.open_dataset(i)
        if i.split('_')[-3][:3] == 'ssp' or nbp[0].split('_')[-3][:4] == 'BSSP':
            df = df.sel(time=slice('2016-01-01', '2100-12-31'))
        else:
            df = df.sel(time=slice('1851-01-01', '2014-12-31'))
        
        if name == 'nbp':
            if model== "CESM2-LE":
                nbp2 = np.asarray(df.NBP.values).ravel()
            else:        
                nbp2 = np.asarray(df.nbp.values).ravel()
        if name == 'gpp':
            if model== "CESM2-LE":
                nbp2 = np.asarray(df.GPP.values).ravel()
            else:        
                nbp2 = np.asarray(df.gpp.values).ravel()
                
        
        if period == '2016_2100':
            if i.split('_')[-4]=='MPI-ESM1-2-LR' and i.split('_')[-3]=='ssp370' and i.split('_')[-2][1:3]=='2i':
                mean_all = np.delete(mean_all, -1, axis=0)
            elif i.split('_')[-4]=='MPI-ESM1-2-LR' and i.split('_')[-3]=='ssp370' and i.split('_')[-2][1:3]=='6i':
                mean_all = np.delete(mean_all, -1, axis=0)
            elif i.split('_')[-4]=='MPI-ESM1-2-LR' and i.split('_')[-3]=='ssp370' and i.split('_')[-2][1:3]=='8i':
                mean_all = np.delete(mean_all, -1, axis=0)
            
            elif i.split('_')[-4]=='MPI-ESM1-2-LR' and i.split('_')[-3]=='ssp585' and i.split('_')[-2][1:3]=='2i':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
            elif i.split('_')[-4]=='MPI-ESM1-2-LR' and i.split('_')[-3]=='ssp585' and i.split('_')[-2][1:3]=='6i':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
            elif i.split('_')[-4]=='IPSL-CM6A-LR' and i.split('_')[-3]=='ssp370' and i.split('_')[-2][1:3]=='6i':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
        
            elif i.split('_')[-4]=='IPSL-CM6A-LR' and i.split('_')[-3]=='ssp585' and i.split('_')[-2][1:3]=='4i':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
            elif i.split('_')[-4]=='CESM2-LE' and i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:6]=='10':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
                
            elif i.split('_')[-4]=='CESM2-LE' and i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:6]=='11':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
                
            else: 
                if np.isnan(nbp2).any():
                    print('this contains nan {}'.format(i))
                else:
                    mean_all[n] = nbp2
                    code_list.append('_' + i.split('_')[-3] + i.split("_")[-2])
                    n += 1
        else:
            if i.split('_')[-5]=='CESM2-LE' and i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:6]=='10':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
                
            elif i.split('_')[-5]=='CESM2-LE' and i.split('_')[-3][-4:]=='smbb' and i.split('_')[-2][4:6]=='11':
                print(i)
                mean_all = np.delete(mean_all, -1, axis=0)
                
            else: 
                mean_all[n] = nbp2
                code_list.append(i.split('_')[-3][-4:] + '_' + i.split("_")[-2])
                n += 1
                
                
    print(mean_all)
    # print(code_list)
    # mean_all = pd.DataFrame(mean_all, index=code_list, columns=date) 
    code_list  = pd.DataFrame(code_list)    
    
    # mean_all.to_csv(f_out + "nbp_{}_1851_2014.csv".format(model))
    code_list.to_csv(f_out + "nbp_{}_code_list_{}.csv".format(model, period))
    
    return mean_all, code_list

def slp_all(f_slp, model, f_out, ress, period):
    slp = order_file(f_slp, model, ress, 'slp')
    print(len(slp))
    
    if slp[0].split('_')[-4][:3] == 'ssp' or slp[0].split('_')[-4][:4] == 'BSSP':
        date = np.arange(2015, 2101)
    else:
        date = np.arange(1850, 2015)
    code_list = []
    
    if model== "CESM2-LE":
        if slp[0].split('_')[-4][:3] == 'ssp' or slp[0].split('_')[-4][:4] == 'BSSP':
            mean_all = np.zeros((len(slp), 1031, 18, 36))
        else:
            mean_all = np.zeros((len(slp), 1979, 18, 36))
    else:
        if slp[0].split('_')[-4][:3] == 'ssp' or slp[0].split('_')[-4][:4] == 'BSSP':
            mean_all = np.zeros((len(slp), 1032, 18, 36))
        else:
            mean_all = np.zeros((len(slp), 1980, 18, 36))
            
    print(mean_all.shape)
    n = 0
    for i in slp:
        if i.split('_')[-5]=='MPI-ESM1-2-LR' and i.split('_')[-4]=='ssp370' and i.split('_')[-3][1:3]=='2i':
            mean_all = np.delete(mean_all, -1, axis=0)
        elif i.split('_')[-5]=='MPI-ESM1-2-LR' and i.split('_')[-4]=='ssp370' and i.split('_')[-3][1:3]=='6i':
            mean_all = np.delete(mean_all, -1, axis=0)
        elif i.split('_')[-5]=='MPI-ESM1-2-LR' and i.split('_')[-4]=='ssp370' and i.split('_')[-3][1:3]=='8i':
            mean_all = np.delete(mean_all, -1, axis=0)
        elif i.split('_')[-5]=='MPI-ESM1-2-LR' and i.split('_')[-4]=='ssp585' and i.split('_')[-3][1:3]=='2i':
            print(i)
            mean_all = np.delete(mean_all, -1, axis=0)
        elif i.split('_')[-5]=='MPI-ESM1-2-LR' and i.split('_')[-4]=='ssp585' and i.split('_')[-3][1:3]=='6i':
            print(i)
            mean_all = np.delete(mean_all, -1, axis=0)
            
        elif i.split('_')[-5]=='IPSL-CM6A-LR' and i.split('_')[-4]=='ssp370' and i.split('_')[-3][1:3]=='6i':
            print(i)
            mean_all = np.delete(mean_all, -1, axis=0)
        elif i.split('_')[-5]=='IPSL-CM6A-LR' and i.split('_')[-4]=='ssp585' and i.split('_')[-3][1:3]=='4i':
            print(i)
            mean_all = np.delete(mean_all, -1, axis=0)
            
        elif i.split('_')[-5]=='CESM2-LE' and i.split('_')[-4][-4:]=='smbb' and i.split('_')[-3][4:6]=='10':
            print(i)
            mean_all = np.delete(mean_all, -1, axis=0)
        elif i.split('_')[-5]=='CESM2-LE' and i.split('_')[-4][-4:]=='smbb' and i.split('_')[-3][4:6]=='11':
            print(i)
            mean_all = np.delete(mean_all, -1, axis=0)
            
        else:
            # print(i)
            code_list.append(i.split("_")[-3])
            df = xr.open_dataset(i)
            if i.split('_')[-4][:3] == 'ssp' or slp[0].split('_')[-4][:4] == 'BSSP':
                df = df.sel(time=slice('2015-01-01', '2100-12-31'))
            else:
                df = df.sel(time=slice('1850-01-01', '2014-12-31'))
            
            if model== "CESM2-LE":
                slp2 = np.asarray(df.PSL.values)
            else:        
                slp2 = np.asarray(df.psl.values)
            
            mean_all[n] = slp2
            code_list.append(i.split('_')[-4] + '_' + i.split("_")[-2])
            n += 1
        
        # mean_all[n] = slp2
        # n += 1
    print('this is {}'.format(mean_all.shape))
    # mean_all = pd.DataFrame(mean_all, index=code_list) 
    code_list  = pd.DataFrame(code_list)    
    # print(code_list)
    # mean_all.to_csv(f_out + "slp_{}_1851_2014.csv".format(model))
    code_list.to_csv(f_out + "slp_{}_code_list_{}.csv".format(model, period))
    
    return mean_all, code_list

    
def run_linear_hist(f_slp, f_nbp, resol, model, f_out, period, res, name):
    
    mean_nbp, code_nbp = nbp_all(f_nbp, model, f_out, period, res, name)
    mean_slp, code_slp = slp_all(f_slp, model, f_out, '10_10', period)
    
    nbp = mean_nbp - np.mean(mean_nbp, axis=0)
    djf_all = np.zeros((len(mean_slp), nbp.shape[1], mean_slp.shape[2], mean_slp.shape[3]))
    mam_all = np.zeros((len(mean_slp), nbp.shape[1], mean_slp.shape[2], mean_slp.shape[3]))
    
    for i in range(len(mean_slp)):
        season = SeasonFilter(mean_slp[i])
        if model == 'CESM2-LE':
            djf_all[i], mam_all[i], jja, son = season.season_cesm()
        else:
            djf_all[i], mam_all[i], jja, son = season.season()
    print(djf_all.shape)
    sea = [djf_all, mam_all]
    seas = ['djf', 'mam']
    for i in range(len(sea)):
        slp_train = sea[i][:len(sea[i])//2].reshape(sea[i][:len(sea[i])//2].shape[0]*sea[i].shape[1], sea[i].shape[2]*sea[i].shape[3])    
        nbp_train = nbp[:len(nbp)//2].reshape(-1, 1)
       
        slp_test = sea[i][len(sea[i])//2:].reshape(sea[i][len(sea[i])//2:].shape[0]*sea[i].shape[1], sea[i].shape[2]*sea[i].shape[3])   
        nbp_test = nbp[len(nbp)//2:].reshape(-1, 1)
        print('this is slp_train {}'.format(slp_train.shape))
        print('this is nbp_train {}'.format(nbp_train.shape))
        print('this is slp_test {}'.format(slp_test.shape))
        print('this is slp_test {}'.format(nbp_test.shape))
        rr = RidgeRegression(sea[i], nbp)
        slp, carb, test_x, test_y = rr.stand(slp_train, nbp_train, 
                                            slp_test, nbp_test)
        
        d_linear = rr.ridge_linear(slp, carb, test_x, test_y) 
        d_pre = np.asarray(d_linear['pre_y']).squeeze().reshape(-1, 1)
        d_pre = d_pre * np.std(nbp_test.ravel()) + np.mean(nbp_test.ravel())
        d_resi = mean_nbp[len(sea[i])//2:].ravel() - d_pre.ravel()
        
        d_linear2 = rr.ridge_linear(test_x, test_y, slp, carb) 
        d_pre2 = np.asarray(d_linear2['pre_y']).squeeze().reshape(-1, 1)
        d_pre2 = d_pre2 * np.std(nbp_train.ravel()) + np.mean(nbp_train.ravel())
        d_resi2 = mean_nbp[:len(sea[i])//2].ravel() - d_pre2.ravel()
        
        d_linear = pd.DataFrame(d_linear)
        d_pre = pd.DataFrame(d_pre)
        d_resi = pd.DataFrame(d_resi)
        
        d_linear2 = pd.DataFrame(d_linear2)
        d_pre2 = pd.DataFrame(d_pre2)
        d_resi2 = pd.DataFrame(d_resi2)
        
        d_line = pd.concat([d_linear2, d_linear])
        d_p = pd.concat([d_pre2, d_pre])
        d_res = pd.concat([d_resi2, d_resi])
        print(len(d_res))
        
        d_line.to_csv(f_out + 'Ridge_mix_all_{}_{}_{}d_1851_2014_linear.csv'
                        .format(model, seas[i], resol))
        d_p.to_csv(f_out + 'Ridge_mix_all_{}_{}_{}d_1851_2014_pre.csv'
                        .format(model, seas[i], resol), index=False)
        d_res.to_csv(f_out + 'Ridge_mix_all_{}_{}_{}d_1851_2014_resi.csv'
                        .format(model, seas[i], resol), index=False)
    
def pre_plot(f_in, f_out, name, peri, name2):
    if peri == '1851_2014':
        date = np.arange(1851, 2015)
    else:
        date = np.arange(2016, 2101)
        
    seas = ['djf', 'mam']
    mode = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    
    for s in seas:
        print(s)
        fig, ax = plt.subplots(5, 1, figsize=(7.4, 8), dpi=300)
        n = 0
        for j in mode:
            for i in [i for i in os.listdir(f_in) if i.endswith("{}.csv".format(name)) and 
                    i.split("_")[1]=='mix' and i.split("_")[4]==s and 
                    i.split("_")[3]==j]:
                print(i)
                df = pd.read_csv(os.path.join(f_in, i))
                df = np.asarray(df).reshape(-1, len(date))
                print(df.shape)
                for k in range(len(df)):
                    ax[n].plot(date, df[k], alpha=0.4, 
                                color = '#2CDDCB', lw=0.4)
                ax[n].plot(date, np.mean(df, axis=0), color= '#1DAFA1', 
                        lw = 1.5, label='{}'.format(j))
                ax[n].set_ylabel(r'$gC \cdot m^{-2} \cdot yr^{-1}$')
                if name2 == 'nbp':
                    ax[n].set_ylim(-30, 30)
                if name2 == 'gpp':
                    ax[n].set_ylim(300, 1100)
                    
                ax[n].axhline(y=0, color='k',lw=.5, alpha=0.5, linestyle='--')
                ax[n].legend(frameon=False,  loc='upper left')
                
                n += 1
        for a in ax.flat:
            a.label_outer()
        plt.xlabel('Year')
        plt.savefig(f_out + '{}_mix_all_{}_annu_sum_global_{}_{}.png'.format(name2, s, peri, name), dpi=300)
        plt.close()


def ra_plot(f_in, f_out, name):
    date = np.arange(1851, 2015)
    mode = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    
    fig, ax = plt.subplots(5, 1, figsize=(7.4, 8), dpi=300)
    n = 0
    for j in mode:
        for i in [i for i in os.listdir(f_in) if i.endswith("{}.csv".format(name)) and 
                  i.split("_")[1]=='mix' and
                  i.split("_")[3]==j]:
            print(i)
            df = pd.read_csv(os.path.join(f_in, i))
            df = np.asarray(df).reshape(-1, 164)
            print(df.shape)
            for k in range(len(df)):
                ax[n].plot(date, df[k], alpha=0.4, 
                            color = '#2CDDCB', lw=0.4)
            ax[n].plot(date, np.mean(df, axis=0), color= '#1DAFA1', 
                    lw = 1.5, label='{}'.format(j))
            ax[n].set_ylabel(r'$gC \cdot m^{-2} \cdot yr^{-1}$')
            ax[n].set_ylim(-30, 30)
            ax[n].axhline(y=0, color='k',lw=.5, alpha=0.5, linestyle='--')
            ax[n].legend(frameon=False,  loc='upper left')
            
            n += 1
    for a in ax.flat:
        a.label_outer()
    plt.xlabel('Year')
    plt.savefig(f_out + 'nbp_mix_all_annu_sum_global_1851_2014_{}.png'.format(name), dpi=300)
    plt.close()

def run_linear_future(f_slp, f_nbp, resol, model, scenario, f_out, period, res, name):
    
    if not os.path.isdir(f_out + scenario):
        os.mkdir(f_out + scenario)
        print(f_out + scenario)
    
    mean_nbp, code_nbp = nbp_all(f_nbp, model, f_out, period, res, name)
    mean_slp, code_slp = slp_all(f_slp, model, f_out, '10_10_fut', period)
    
    nbp = mean_nbp - np.mean(mean_nbp, axis=0)
    djf_all = np.zeros((len(mean_slp), nbp.shape[1], mean_slp.shape[2], mean_slp.shape[3]))
    mam_all = np.zeros((len(mean_slp), nbp.shape[1], mean_slp.shape[2], mean_slp.shape[3]))
    
    for i in range(len(mean_slp)):
        season = SeasonFilter(mean_slp[i])
        if model == 'CESM2-LE':
            djf_all[i], mam_all[i], jja, son = season.season_cesm()
        else:
            djf_all[i], mam_all[i], jja, son = season.season()
     
    sea = [djf_all, mam_all]
    seas = ['djf', 'mam']
    
    for i in range(len(sea)):
        print(seas[i])
        slp_train = sea[i][:len(sea[i])//2].reshape(sea[i][:len(sea[i])//2].shape[0]*sea[i].shape[1], sea[i].shape[2]*sea[i].shape[3])    
        nbp_train = nbp[:len(nbp)//2].reshape(nbp[:len(nbp)//2].shape[0]*nbp.shape[1]).reshape(-1, 1)
       
        slp_test = sea[i][len(sea[i])//2:].reshape(sea[i][len(sea[i])//2:].shape[0]*sea[i].shape[1], sea[i].shape[2]*sea[i].shape[3])   
        nbp_test = nbp[len(nbp)//2:].reshape(nbp[len(nbp)//2:].shape[0]*nbp.shape[1]).reshape(-1, 1)
        rr = RidgeRegression(sea[i], nbp)
        slp, carb, test_x, test_y = rr.stand(slp_train, nbp_train, 
                                            slp_test, nbp_test)
        
        d_linear = rr.ridge_linear(slp, carb, test_x, test_y) 
        d_pre = np.asarray(d_linear['pre_y']).squeeze().reshape(-1, 1)
        d_pre = d_pre * np.std(nbp_test.ravel()) + np.mean(nbp_test.ravel())
        d_resi = mean_nbp[len(sea[i])//2:].ravel() - d_pre.ravel()
        
        d_linear2 = rr.ridge_linear(test_x, test_y, slp, carb) 
        d_pre2 = np.asarray(d_linear2['pre_y']).squeeze().reshape(-1, 1)
        d_pre2 = d_pre2 * np.std(nbp_train.ravel()) + np.mean(nbp_train.ravel())
        d_resi2 = mean_nbp[:len(sea[i])//2].ravel() - d_pre2.ravel()
        print(d_resi2.shape)
        
        d_linear = pd.DataFrame(d_linear)
        d_pre = pd.DataFrame(d_pre)
        d_resi = pd.DataFrame(d_resi)
        
        d_linear2 = pd.DataFrame(d_linear2)
        d_pre2 = pd.DataFrame(d_pre2)
        d_resi2 = pd.DataFrame(d_resi2)
        
        d_line = pd.concat([d_linear2, d_linear])
        d_p = pd.concat([d_pre2, d_pre])
        d_res = pd.concat([d_resi2, d_resi])
        
       
        d_line.to_csv(f_out + '{}/Ridge_mix_all_{}_{}_{}_{}d_2016_2100_linear.csv'
                        .format(scenario, model, scenario, seas[i], resol))
        d_p.to_csv(f_out + '{}/Ridge_mix_all_{}_{}_{}_{}d_2016_2100_pre.csv'
                        .format(scenario, model, scenario, seas[i], resol), index=False)
        d_res.to_csv(f_out + '{}/Ridge_mix_all_{}_{}_{}_{}d_2016_2100_resi.csv'
                        .format(scenario, model, scenario, seas[i], resol), index=False)


if __name__ == '__main__':
    f_slp = ".../data/psl/"
    f_nbp = ".../data/nbp/"
    f_gpp = ".../data/gpp/"
    f_out = ".../results/RR/"
    f_nbp_pre = ".../results/RR/history/nbp/"
    f_gpp_pre = ".../results/RR/history/gpp/"
    
    f_slp_fut = ".../data/psl_future/"
    f_nbp_fut = ".../data/nbp_future/"
    f_gpp_fut = ".../data/gpp_future/"
    f_nbp_pre_fut = ".../results/RR/future/nbp/"
    f_gpp_pre_fut = ".../results/RR/future/gpp/"
    
    # historical NBP
   
    mode = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
   
    # for i in mode:
        
    #     run_linear_hist(f_slp, f_nbp, 10, i, f_out + 'history/nbp/', '1851_2014', 'global', 'nbp')
    #     run_linear_hist(f_slp, f_gpp, 10, i, f_out + 'history/gpp/', '1851_2014', 'global', 'gpp')
        
    # pre_plot(f_nbp_pre, f_out + 'history/nbp/', 'pre', '1851_2014', 'nbp')
    # pre_plot(f_nbp_pre, f_out + 'history/nbp/', 'resi', '1851_2014', 'nbp')
    # pre_plot(f_gpp_pre, f_out + 'history/gpp/', 'pre', '1851_2014', 'gpp')
    # pre_plot(f_gpp_pre, f_out + 'history/gpp/', 'resi', '1851_2014', 'gpp')
    
    # # future NBP
    sce = ['ssp126', 'ssp245', 'ssp370', 'ssp585']
   
    mode1 = ['ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
   
    # for k in mode1: 
    #     for p in sce:
    #         print(p)
    #         run_linear_future(f_slp_fut+p+'/', f_nbp_fut+p+'/', 10, k, p, f_out + 'future/nbp/', '2016_2100', 'global_fut', 'nbp')
    #         run_linear_future(f_slp_fut+p+'/', f_gpp_fut+p+'/', 10, k, p, f_out + 'future/gpp/', '2016_2100', 'global_fut', 'gpp')
   
    # run_linear_future(f_slp_fut+'ssp370/', f_nbp_fut+'ssp370/', 10, 'CESM2-LE', 'ssp370', f_out + 'future/nbp/', '2016_2100', 'global_fut', 'nbp')
    # run_linear_future(f_slp_fut+'ssp370/', f_gpp_fut+'ssp370/', 10, 'CESM2-LE', 'ssp370', f_out + 'future/gpp/', '2016_2100', 'global_fut', 'gpp')
    
    