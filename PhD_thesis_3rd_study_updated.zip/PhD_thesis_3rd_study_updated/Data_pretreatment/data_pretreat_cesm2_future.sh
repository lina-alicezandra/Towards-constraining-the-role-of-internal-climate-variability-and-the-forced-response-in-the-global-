#! /bin/bash

# pre-treatment steps for CMIP6:
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. year * area * 1000000 / 10**12 convert to PgC
# 4. remap to 
# shape   df_grid        resolution
# 144x72  df_grid=1,1    2.5x2.5 remeber it can only show 2 not 2.5
# 72x36   df_grid=2,2    5 x 5
# 36x18   df_grid=4,4    10x10
# 18x9    df_grid=8,8    20x20
# 12x6    df_grid=12,12  30x30
# 8x4     df_grid=18,18  45x45
# 6x3     df_grid=24,24  60x60
# 2x1     df_grid=72,72  180x180
# 1x1     df_grid=144,72 360x180    

# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area
# npp future ssp370 has no 1251 011-020

get_future_data_cesm2 () {

varia=$1

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia""_future/ssp370/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia""_future/""$varia""_ann_temp_.nc"

echo $f_out
echo $f_temp

for line in $f_in/*future*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 5-6)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out/"$varia""_ann_CESM2-LE_"$df3"_global.nc")
    echo $df_out
    
    cdo -L -yearsum -muldpm -mulc,24 -mulc,3600 $line $f_temp
    cdo -L -fldmean $f_temp $df_out

done 
rm $f_temp 

}

get_future_data_cesm2_litterc () {

varia=$1

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia""_future/ssp370/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia""_future/""$varia""_ann_temp_.nc"

echo $f_out
echo $f_temp

for line in $f_in/*future*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 6-7)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out/"$varia""_ann_CESM2-LE_"$df3"_global.nc")
    echo $df_out
    
    cdo -L -yearsum -muldpm -mulc,24 -mulc,3600 $line $f_temp
    cdo -L -fldmean $f_temp $df_out

done 
rm $f_temp 

}


# declare -a vari=(nbp gpp npp)
# for va in ${vari[@]}
# do
# get_future_data_cesm2 $va 
# done

# declare -a vari=(litterc_hr soilc_hr)
# for va in ${vari[@]}
# do
# get_future_data_cesm2_litterc $va 
# done

# declare -a vari=(npp)
# for va in ${vari[@]}
# do
# get_future_data_cesm2 $va 
# done
