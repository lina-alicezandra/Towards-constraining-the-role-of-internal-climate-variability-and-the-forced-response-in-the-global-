#! /bin/bash

# pre-treatment steps for CMIP6:
# unit kg m-2 s-1
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. year * 1000 convert to gC/m2/year
# 4. remap to 
# shape   df_grid        resolution
# 144x72  df_grid=1,1    2.5x2.5 remeber it can only show 2 not 2.5
# 72x36   df_grid=2,2    5 x 5
# 36x18   df_grid=4,4    10x10
# 18x9    df_grid=8,8    20x20
# 12x6    df_grid=12,12  30x30
# 8x4     df_grid=18,18  45x45
# 6x3     df_grid=24,24  60x60
# 2x1     df_grid=72,72  180x180
# 1x1     df_grid=144,72 360x180  


# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area, this is 
# achieved by CDO fldmean, which automatically area-weighting

get_future_data () {
varia=$1
code=$2 

add="_future"

f_out="/climca/people/lina/3rd_year_research/data/$varia$add/"
f_code_list=$f_out"code_list_all_$code.csv"
f_line2="/climca/people/lina/3rd_year_research/data/$varia/""$varia""_ann_temp_2.nc"
f_mask1="/climca/data/cmip6-ng/masks/fx/native/sftlf000_fx_CanESM5_historical_r8i1p2f1_native.nc"
f_mask2="/climca/people/lina/3rd_year_research/data/mask_2.5.nc"
f_mask="/climca/people/lina/3rd_year_research/data/ocean_mask.nc"
f_ann="/climca/data/cmip6-ng/$varia/ann/g025/"$varia"_ann_CanESM5_historical_r10i1p1f1_g025.nc"

echo $f_code_list
f_temp="/climca/people/lina/3rd_year_research/data/$varia$add/""$varia$add""_ann_temp_.nc"

# mkdir $f_out"$res1""_""$res2"
mkdir $f_out"$code"
echo $f_code_list
echo $f_out
echo $f_temp

while read line
do
    echo $line
    df1=$(echo $line| cut -d'_' -f 2-5)
    df_out=$(echo $f_out"$code"/"$varia""_"$df1"_global.nc")
    echo $df_out

     # create ocean map
    model_name=$(echo $line| cut -d'_' -f 3)
    echo $model_name

    if echo "$model_name" | grep -q "CanESM5"
    then 	
            echo line
            cdo -remapnn,$f_ann $f_mask1 $f_mask2  
            cdo -setctomiss,0 -addc,1 -mulc,-1 $f_mask2 $f_mask
            
            cdo -L -muldpy -mulc,24 -mulc,3600 -select,name=$varia $line $f_temp
            cdo -mul $f_temp $f_mask $f_line2
            cdo -L -mulc,1000 -fldmean $f_line2 $df_out
            
    else
            cdo -L -muldpy -mulc,24 -mulc,3600 -select,name=$varia $line $f_temp
            cdo -L -mulc,1000 -fldmean $f_temp $df_out 
    fi
    

done < $f_code_list
rm $f_temp 

}

# declare -a vari=(nbp gpp)
# declare -a scen=(ssp126 ssp245 ssp370 ssp585)
# for va in ${vari[@]}
# do

# for sc in ${scen[@]}
# do
# get_future_data $va $sc
# done
# done

# declare -a vari=(ra rh)
# declare -a scen=(ssp126 ssp245 ssp370 ssp585)
# for va in ${vari[@]}
# do

# for sc in ${scen[@]}
# do
# get_future_data $va $sc
# done
# done
