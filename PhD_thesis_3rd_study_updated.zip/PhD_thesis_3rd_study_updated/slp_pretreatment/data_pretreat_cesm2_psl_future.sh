#! /bin/bash

# pre-treatment steps for CMIP6:
# 1. month = per pixel * 24 * 3600 * days_in_month
# 2. year = month.resample to annual sum
# 3. year * area * 1000000 / 10**12 convert to PgC
 

# this is calculate global mean not global sum of NBP, so NBP per pixel is 
# area-weighted by default CDO function, not by the actual area

get_data_cesm2 () {

varia=$1
df_shape1=$2
df_shape2=$3


res1=$(expr 360 / $df_shape1  | bc )
res2=$(expr 180 / $df_shape2  | bc )
echo $res1 
echo $res2 

f_in="/climca/people/lina/3rd_year_research/data/CESM2-LE_ori/$varia"
f_out="/climca/people/lina/3rd_year_research/data/$varia""_future/ssp370/"
f_temp="/climca/people/lina/3rd_year_research/data/$varia""_future/""$varia""_ann_temp_.nc"
f_temp2="/climca/people/lina/3rd_year_research/data/$varia""_future/""$varia""_ann_temp_2.nc"

# ls $f_in/*future*.nc

# mkdir $f_out"$res1""_""$res2"
echo $f_out"$res1""_""$res2" 
echo $f_out
echo $f_temp

for line in $f_in/*future*.nc
do
    echo $line
    df1=$(echo $line| cut -d'/' -f 9)
    df2=$(echo $df1| cut -d'_' -f 5-6)
    df3=$(echo $df2| cut -d'.' -f 1-2)
    echo $df3
    df_out=$(echo $f_out/"$varia""_ann_CESM2-LE_"$df3"_""$res1""_""$res2.nc")
    echo $df_out
    
    cdo -remapcon,"r"$df_shape1"x"$df_shape2 $line $df_out

    # break
done 
rm $f_temp 

}

declare -a vari=(psl)
for va in ${vari[@]}
do
get_data_cesm2 $va 36 18
done
