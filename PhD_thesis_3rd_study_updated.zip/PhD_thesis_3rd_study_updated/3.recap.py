#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""

@author: Na Li na.li@uni-leipzig.de

This is to calculate the time of emergence in 10 RECCAP-2 domains in historical run.

Function heatmap is to plot figure 2, S2, S3, S4

"""


import os
import numpy as np
import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import numpy
from cmip_treatment import linear_regre
import seaborn as sns 
from matplotlib.colors import BoundaryNorm

def order_file(f_in, model, res):
    f_in2 = os.path.join(f_in, res)
    f_new = []
    f_new2 = []
    for i in [i for i in sorted(os.listdir(f_in2)) if i.endswith('.nc') and i.split('_')[2]==model]:
        f_new.append(os.path.join(f_in2, i))
        
    if model == "CESM2-LE":
        f_new2 = sorted(f_new)
    else:    
        for j in range(1, len(f_new)+1):
            for i in f_new:
                if i.split('_')[-1] == 'global.nc' and int(i.split('_')[-2][1:-6])==j: 
                       f_new2.append(i) 
                if i.split('_')[-1] != 'global.nc' and int(i.split('_')[-3][1:-6])==j: 
                       f_new2.append(i) 
    if model == "ACCESS-ESM1-5":
        f_new2.remove(f_new2[24])
        f_new2.remove(f_new2[20])      
    # df = pd.DataFrame(f_new2)
    # df.to_csv(f_in + 'code_list_{}.csv'.format(model), index=False)
    # df.to_csv(f_in + 'test2.csv', index=False)
    return f_new2

def recap(f_in, f_out, model, resol, re_cap, name):
    f_list = order_file(f_in, model, resol)
    mean_glob = np.zeros((len(f_list), 10, 164))
    print(mean_glob.shape)
    n = 0
    rec_map = xr.open_dataset(re_cap)
    # rec_map.mask10r.plot()
    
    rec_map = np.asarray(rec_map.mask10r.values).reshape((72, 144))
    # rec_map = np.where(rec_map<1, 1, rec_map) 
    rec_map2 = np.rint(rec_map)
    
    plt.pcolor(rec_map2, vmin=0, vmax=11, cmap='BuPu')
    plt.colorbar()
    
    plt.savefig(f_out + 'reccap_map.png')
    plt.close()
    
    for i in f_list:
       
        df = xr.open_dataset(i)
        
        df = df.sel(time=slice('1851-01-01', '2014-12-31'))
        df.coords['mask'] = (('lat', 'lon'), rec_map2.data)
        
        def region(gpp):
            gpp_allregion = np.zeros((10, 164))
            for j in range(1, 11):
                gpp_reg1 = gpp.where(gpp.mask == j)
                weights = np.cos(np.deg2rad(gpp_reg1.lat))
                gpp_weighted = gpp_reg1 * weights
                gpp_allregion[j-1] = gpp_weighted.mean(dim=('lat', 'lon'))
                
            return gpp_allregion
        
        if name == 'nbp':
            if model == 'CESM2-LE':
                mean_glob[n] = region(df.NBP)
            else:
                mean_glob[n] = region(df.nbp)
        if name == 'gpp':
            if model == 'CESM2-LE':
                mean_glob[n] = region(df.GPP)
            else:
                mean_glob[n] = region(df.gpp)
        if name == 'res':
            if model == 'CESM2-LE':
                mean_glob[n] = region(df.RES)
            else:
                mean_glob[n] = region(df.res)
        n += 1
        break
    
    print(mean_glob[0, :, :3])
    with open(f_out + 'Recap_{}_{}_annu_mean_1851_2014.npy'.format(name, model), 'wb') as f:
        np.save(f, mean_glob)

def emerg_recap(f_in, f_global, f_out, model, star, mid, end, name):
    recap_region = ['Global', 'North_America', 'South_America', 'Europe', 'Africa', 'Russia', 'West_Asia',
     'South_Asia', 'East_Asia', 'Southeast_Asia', 'Australasia']
    d = {}
    date = np.arange(1851, 2015)
    for i in [i for i in os.listdir(f_in) if i.split('_')[1]==name 
              and i.endswith('npy') and i.split('_')[2]==model]:
        print(i)
        
        si = ['signal', 'noise', 'emergence']
        glob = []
        for s in si:
            for k in [k for k in os.listdir(f_global) if k.endswith('.csv')
                      and k.split('_')[2]== s]:
                print(k)
                df2 = pd.read_csv(os.path.join(f_global, k), index_col=0)
                glob.append(np.around(np.asarray(df2.loc[s][model]), decimals=1, out=None))
        print(glob)
        d['Global'] = glob
        df = np.load(os.path.join(f_in, i))
        print(df.shape)
        
        st = np.argwhere(date==star)[0][0]
        en = np.argwhere(date==end)[0][0]
        for j in range(df.shape[1]):
            print(j)
            df2 = df[:, j, st:en+1]
            print(df2.shape)
            S = np.mean(df2, axis=0)[mid-star+1:]
            SS, r, p = linear_regre(np.arange(len(S)), S)
            # S_new = SS
            if p < 0.05:
                S_new = SS
            else:
                S_new = np.nan 
            
            N = np.std(df2[:, :mid-star+1])
            print("this is {}".format(N))
            if N == 0:
                N = np.nan
            if N < 0.00001 and N > -0.00001:
                N = np.nan
            
            S_new = np.absolute(S_new)
            emer = 2*N/S_new 
            if emer == np.inf:
                emer = np.nan
            
            S_new = np.around(S_new, decimals=1, out=None)
            N = np.around(N, decimals=1, out=None)
            emer = np.around(emer, decimals=1, out=None)
            print(recap_region[j+1])
            d[recap_region[j+1]] = [S_new, N, emer]
            
        
        d = pd.DataFrame(d, index=['Slope', 'N', 'emer'])
        print(d)
        # d.to_csv(f_out + 'Recap_{}_emergence_{}.csv'.format(name, model))
    
def heat_map(f_in, f_out, name):
    si = ['emer', 'N', 'Slope']
    lab =  ['ToE (Years)', 'N', 'S']
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5', 'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    n = 0
    for i in si:
        df = {}
        for k in code:
            for h in [h for h in os.listdir(f_in) if h.endswith('{}.csv'.format(k)) 
                      and h.split('_')[1]==name]:
                print(h)
                file = pd.read_csv(f_in + h, index_col = 0)
                df[k] = file.loc[i]
        df = pd.DataFrame(df)
        print(df)
        
        fig, ax = plt.subplots(figsize=(7,4)) 
        df = np.around(df, decimals=1, out=None).T
        cmap = sns.color_palette('rocket_r', 10)
        if i == 'emer':
            vmin_ = 0
            vmax_ = 100
            df = np.around(df, decimals=0, out=None)
        if i == 'N':
            vmin_ = 10
            vmax_ = 60
            
        if i == 'Slope':
            vmin_ = 0.25
            vmax_ = 2.75
            
        print(vmin_)
        print(df)
        sns.heatmap(df, cmap=cmap, vmin=vmin_, vmax=vmax_, cbar=True, 
                    cbar_kws={'label': lab[n]},
                    annot=True, annot_kws={'size': 8}, fmt='g') 
        plt.tight_layout()
        plt.savefig(f_out + 'heatmap_{}_{}_recap.pdf'.format(name, i), dpi=300)
        plt.close()
        n += 1
              
if __name__ == '__main__':
    f_nbp = '/climca/people/lina/3rd_year_research/data/nbp/'
    f_gpp = '/climca/people/lina/3rd_year_research/data/gpp/'
    f_nbp_global = '/climca/people/lina/3rd_year_research/results/emerge/nbp_emer/'
    f_gpp_global = '/climca/people/lina/3rd_year_research/results/emerge/gpp_emer/'
    f_res = '/climca/people/lina/3rd_year_research/data/res/'
    f_res_global = '/climca/people/lina/3rd_year_research/results/emerge/res_emer/'
    
    f_out = '/climca/people/lina/3rd_year_research/results/reccap/'
    re_cap = '/climca/people/lina/3rd_year_research/data/reccap2_10land_5x5.nc'
    code = ['CESM2-LE', 'ACCESS-ESM1-5', 'CanESM5',  'IPSL-CM6A-LR', 'MPI-ESM1-2-LR']
    code = ['CESM2-LE']
    
    star, mid, end = 1930, 1959, 2009
    
    # for i in code:
    #     print(i)
    #     recap(f_nbp, f_out, i, '2_2', re_cap, 'nbp')
    #     emerg_recap(f_out, f_nbp_global, f_out, i, star, mid, end, 'nbp')
    heat_map(f_out, f_out, 'nbp')
    
    # for i in code:
    #     print(i)
    #     # recap(f_gpp, f_out, i, '2_2', re_cap, 'gpp')
    #     emerg_recap(f_out, f_gpp_global, f_out, i, star, mid, end, 'gpp')
    heat_map(f_out, f_out, 'gpp')
    
    # for i in code:
    #     print(i)
    #     recap(f_res, f_out, i, '2_2', re_cap, 'res')
    #     emerg_recap(f_out, f_res_global, f_out, i, star, mid, end, 'res')
    heat_map(f_out, f_out, 'res')
    
   